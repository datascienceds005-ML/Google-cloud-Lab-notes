// content_c.js — Sections 8-11 + appendices of the Fixed-Context Rolling Memory blueprint
module.exports = (H) => {
  const { h1, h2, body, bodyRuns, tableCaption, makeTable } = H;
  const out = [];

  // ── 8. Coherence Safeguards ──
  out.push(h1("8. Long-Horizon Coherence Safeguards"));
  out.push(body("External memory only helps if it stays consistent over hundreds of turns. Five safeguards address the specific ways a fixed-context system drifts, contradicts itself, or lets details slip."));
  out.push(h2("8.1 Single Sources of Truth"));
  out.push(body("The character registry is the only authority for names, aliases, and relationships, so the system never wavers between a character's name and a descriptive label across turns. The event timeline is the only authority for plot order, and every answer that makes a plot claim carries its timestamp. The motif ledger is the only authority for symbolic threads. When an answer needs one of these, the relevant records enter through the evidence slot, so even a question asked four hundred turns apart receives the same canonical facts rather than a re-paraphrase of an earlier answer."));
  out.push(h2("8.2 Contradiction Discipline"));
  out.push(body("Because the evidence slot carries the canonical records for the entities a question touches, each new answer is generated in the presence of what the system already believes, which makes contradictions visible at generation time rather than after the fact. When a contradiction does surface, resolution is mechanical: the immutable Archive outranks any summary or record, the conflicting Store value is superseded with the earlier version preserved, and the correction is noted in the question-and-answer digest so the same conflict is not silently re-litigated later."));
  out.push(h2("8.3 Drift Control for Summaries"));
  out.push(body("Summary drift, in which repeated rewriting slowly erodes or distorts facts, is blocked structurally rather than by vigilance. The Spine is always rebuilt from Store records, never from its own previous text, which removes the compounding step where drift breeds. Every line in the rebuilt Spine must trace to at least one record, and the periodic audit pass samples Spine claims and verifies them against the Archive, converting drift from a silent failure into a detectable one with a known repair, namely a rebuild."));
  out.push(h2("8.4 Spoiler State and Preference Memory"));
  out.push(body("The spoiler-state marker records how far into the film the user has actually progressed, and retrieval never returns evidence from beyond that timestamp. This lets the system answer questions about the first act safely for a first-time viewer even though the Archive holds the complete film. Standing preferences, such as a spoiler ceiling, preferred answer length, or characters of particular interest, live as records in the State Store and are injected through the contract slot, so the system keeps honoring them without ever needing them restated."));

  // ── 9. Memory Arithmetic ──
  out.push(h1("9. Memory Arithmetic and RAM Assurance"));
  out.push(body("The design's feasibility rests on a handful of quantities, computed here for a representative two-hour feature and a representative mid-size open-weights architecture. All figures are planning estimates, to be validated in Phases A and B, but their orders of magnitude are what matter, and those are unambiguous. Table 4 establishes how much the system must remember; Table 5 establishes what answering costs in RAM."));
  out.push(tableCaption("Table 4. How much memory a two-hour film actually generates"));
  out.push(makeTable(
    ["Quantity", "Estimate", "Basis"],
    [
      ["Dialogue volume", "8,400-11,500 words", "Speech in about 65 percent of runtime, at 110-150 words per minute"],
      ["Transcript size", "About 13,300 tokens at midpoint", "English prose averages roughly 0.75 words per token"],
      ["Scene summaries", "3,600 words", "45 scenes at about 80 words each"],
      ["Character dossiers", "1,280 words", "8 principals at about 160 words each"],
      ["Ledgers and observations", "About 3,700 words", "Motifs, relationships, glossary, ingestion notes"],
      ["Full analysis corpus", "About 18,600 words, roughly 24,700 tokens", "The permanent memory the system must hold"],
      ["Share usable per turn", "2,000 of 24,700 tokens, about 8 percent", "Why retrieval, not context growth, carries the load"],
      ["Story Spine share", "About 650 tokens, or 2.6 percent", "The constant, always-injected layer"],
    ],
    [30, 32, 38],
  ));
  out.push(tableCaption("Table 5. RAM budget during a single answering turn, free CPU tier"));
  out.push(makeTable(
    ["Component", "Estimate (GB)", "Note"],
    [
      ["4-bit weights of an 8B-class model", "4.8", "The dominant consumer, but static: it never grows with usage"],
      ["Inference runtime overhead", "1.2", "Framework buffers and allocator slack"],
      ["Key-value cache at the fixed window", "0.3", "About 144 KB per token; 0.28 GB at 2,000 tokens, versus about 18 GB at 128,000"],
      ["Retrieval index and state caches", "0.3", "Record index plus recently used evidence slices"],
      ["Operating system and headroom", "2.0", "Base system and safety margin"],
      ["Total", "8.6", "Leaves about 7.4 GB of the 16 GB budget unallocated"],
    ],
    [40, 16, 44],
  ));
  out.push(bodyRuns([
    "One line of Table 5 carries the whole argument. The key-value cache is the only memory consumer that grows with context, and the fixed cap converts it from the system's principal risk into a small constant: 0.28 GB at 2,000 tokens against roughly 18 GB at 128,000 tokens, a size that would exceed the entire machine before weights were loaded. Disk tells the same story of headroom. The lightweight uploads of Section 2 put peak disk usage near 0.94 GB, under 2 percent of the 50 GB scratch disk, and after the companion blueprint's gated raw-file deletion the steady-state footprint is about 0.34 GB, with the durable tiers mirrored off-Space. The residual cost is latency: two CPU cores processing a bounded 2,000-token prompt means answers arrive in tens of seconds, a deliberate and honest trade of speed for guaranteed stability.",
  ]));

  // ── 10. Risks ──
  out.push(h1("10. Risks, Limits, and Mitigations"));
  out.push(body("The architecture has known limits, stated here alongside their mitigations rather than discovered later. Table 6 lists the six that matter most."));
  out.push(tableCaption("Table 6. Principal risks and their mitigations"));
  out.push(makeTable(
    ["Risk", "How it shows up", "Mitigation"],
    [
      ["Retrieval miss", "A question targets a detail no record covers", "The answer admits the gap; an optional bounded deep-dive pass analyzes that scene on demand, under the same window budget"],
      ["Summary drift", "Repeated rewriting erodes or distorts facts", "Spine is rebuilt from records, never from itself; audit sampling verifies claims against the Archive"],
      ["Commit failure", "The Space dies mid-session", "Journal-then-mirror commits; recovery resumes from the last good snapshot; at most one turn's facts are re-derived"],
      ["Scratchpad over-compression", "A follow-up loses its antecedent", "Fixed 120 tokens with a last-mentioned entity pointer; older exchanges are already absorbed into the Store by commit"],
      ["Latency spikes", "Dense evidence slices on two CPU cores", "Evidence capped at 700 tokens with rank-ordered truncation; the contract sets honest timing expectations"],
      ["Conflicting corrections", "The user contradicts stored state", "Corrections take top precedence; superseded values are archived, never silently deleted"],
    ],
    [22, 32, 46],
  ));
  out.push(body("Three limits deserve explicit acknowledgment beyond the table. First, the system provides selective recall, not total recall: verbatim material surfaces only when retrieval ranks it, so a demand for exhaustive quotation is served by bounded deep-dive passes rather than by context. Second, the roster is sized for roughly eight principal characters; a sprawling ensemble is handled through Store slices rather than through the Spine, at some cost to always-available context. Third, multi-film sessions require per-film state namespaces, since every tier above assumed one movie. None of these limits threatens the core guarantee, which is bounded RAM and permanent memory; they bound convenience, not correctness."));

  // ── 11. Roadmap ──
  out.push(h1("11. Phased Implementation Roadmap"));
  out.push(body("The roadmap keeps the document's promise of planning without code: each phase is named by responsibility and judged by acceptance criteria, with the ordering chosen so that every phase builds on a verified foundation. Phase A comes first because a window assembler has nothing to assemble until external state exists, and Phase B precedes the interactive phases because the budget mechanism must be proven before anything depends on it."));
  out.push(tableCaption("Table 7. Implementation phases and acceptance criteria"));
  out.push(makeTable(
    ["Phase", "Scope", "Acceptance criteria"],
    [
      ["Phase A: External State Store", "Derive Tier 2 and Tier 3 records from the existing ingestion outputs; mirror to the durable repository; rehydrate caches on cold start", "Every supportable fact retrievable by entity or timestamp; a restart loses nothing"],
      ["Phase B: Window assembler", "Build the six-slot assembly with hard budgets, the truncation policy, and the deep-answer variant", "A 50-question stress suite never exceeds 2,000 tokens; no visual tokens ever present"],
      ["Phase C: Commit and scratchpad", "Per-turn fact extraction, journal-then-mirror writes, scratchpad refresh", "A refresh at any commit boundary loses nothing; user corrections propagate to later answers"],
      ["Phase D: Consolidation", "Background Spine rebuild with fixed eviction order and budget enforcement", "The Spine regenerates from the Store alone within 650 tokens; sampled claims verify against the Archive"],
      ["Phase E: Coherence hardening", "Contradiction checks, spoiler gating, latency validation", "A scripted probe suite passes; no evidence surfaces past the user's spoiler marker; answers land within the stated latency on 2 vCPU"],
    ],
    [20, 40, 40],
  ));
  out.push(body("Phase E closes the loop with the coherence safeguards of Section 8, and its probe suite should be kept as a permanent regression harness: every future change to budgets, ranking, or consolidation cadence is re-run against it. When all five phases pass, the system has the property the brief demanded, stated once more in plain terms: the context window is permanently fixed at 2,000 tokens, sessions refresh without ceremony, and the film is never forgotten."));

  // ── Appendix A ──
  out.push(h1("Appendix A. Glossary"));
  out.push(body("The following terms are used throughout this blueprint with the specific meanings given here."));
  out.push(makeTable(
    ["Term", "Meaning in this document"],
    [
      ["Active window", "The 2,000-token context assembled for a single answer; the only content the model sees that turn"],
      ["Key-value cache", "The working memory a transformer keeps for every token in its context; grows linearly with context and is the principal RAM risk of any growth"],
      ["Story Spine", "The fixed, roughly 650-token rolling master summary injected verbatim into every window"],
      ["Scratchpad", "A 120-token note of the last few exchanges plus the last-mentioned entity, carried between turns for conversational continuity"],
      ["State Store", "The queryable record system of characters, timeline, scenes, motifs, and the question digest; the durable external state"],
      ["Deep Archive", "The append-only store of immutable evidence: transcript, scene summaries, captions, verbatim quotes"],
      ["Commit", "The end-of-turn step that extracts durable facts and writes them to the State Store before any session refresh"],
      ["Consolidation", "The periodic background rewrite of the Story Spine from State Store records under fixed budgets"],
      ["Evidence slice", "The ranked selection of records and quotes placed in the window for one question"],
      ["Visual tokens", "The tokens a vision-language model spends to represent an image; excluded from interactive turns by design"],
      ["Spoiler state", "The marker of the user's revealed progress through the film; gates evidence retrieval to earlier timestamps"],
      ["Durable repository", "The private dataset mirror off the Space where memory survives restarts; local disk is only a cache"],
    ],
    [24, 76],
  ));

  // ── Appendix B ──
  out.push(h1("Appendix B. Token Budget Worksheet"));
  out.push(body("The worksheet consolidates the arithmetic used across the document, for a representative two-hour feature and a representative mid-size open-weights architecture. The words-per-token conversion assumes English prose at roughly 0.75 words per token; corpus figures assume 45 scenes, 8 principal characters, and the dialogue rates of Table 4; the key-value cache figures assume 36 layers, 8 key-value heads, and 128-dimensional heads at half precision, which is why every value here is labeled a planning estimate to be validated in Phases A and B."));
  out.push(makeTable(
    ["Item", "Value"],
    [
      ["Fixed window cap", "2,000 tokens, about 1,500 English words, about 5 pages"],
      ["Always-present slots (contract, Spine, scratchpad)", "920 tokens"],
      ["Per-turn material (evidence, question, answer headroom)", "1,080 tokens"],
      ["Deep-answer variant", "Evidence 480, answer headroom 520; total still 2,000"],
      ["Analysis corpus for the film", "About 18,600 words, roughly 24,700 tokens"],
      ["Corpus coverage per turn", "About 8 percent"],
      ["Key-value cache at the cap", "About 0.28 GB"],
      ["Key-value cache if grown to 128,000 tokens", "About 18 GB, beyond the entire 16 GB budget"],
      ["Full answering-stack RAM", "About 8.6 GB of 16 GB, leaving about 7.4 GB of headroom"],
      ["Peak disk, lightweight profile", "About 0.94 GB, roughly 2 percent of the 50 GB scratch disk"],
      ["Consolidation cadence", "About every 12 turns, or on scratchpad pressure"],
    ],
    [46, 54],
  ));

  // ── Appendix C ──
  out.push(h1("Appendix C. Sources and Basis"));
  out.push(body("The free-tier environment figures used throughout this document, two virtual CPU cores, 16 GB of system RAM, 50 GB of ephemeral storage, and no accelerator on the free hardware class, follow the Hugging Face Spaces documentation at https://huggingface.co/docs/hub/spaces-overview. The observation that modern open-weights vision-language models advertise context windows of 256,000 tokens and beyond, which this architecture deliberately declines to use, follows the official model family documentation at https://github.com/QwenLM/Qwen3-VL. All remaining quantities, dialogue volumes, corpus sizes, key-value cache costs, RAM budget lines, and disk footprints, are the planning estimates computed in Appendix B from stated assumptions, and are intended to be re-measured and corrected during Phases A and B of the roadmap."));

  return out;
};
