// content_a.js — Sections 1-4 of the Fixed-Context Rolling Memory blueprint
module.exports = (H) => {
  const { h1, h2, h3, body, bodyRuns, tableCaption, makeTable } = H;
  const out = [];

  // ── 1. Executive Summary ──
  out.push(h1("1. Executive Summary"));
  out.push(body("This blueprint answers a single, sharply stated question: how can a movie-analysis assistant keep remembering an entire feature film across hours of continuous questioning while its language model is permanently denied more than 2,000 tokens of context per answer, on a Hugging Face free tier that offers 16 GB of RAM, 50 GB of ephemeral scratch disk, and no GPU at any price the project is willing to pay? The constraint is treated as permanent by design. The context window will never grow, not at the tenth question and not at the ten-thousandth, because an expanding context is the single most reliable way to exhaust free-tier memory. The resolution proposed here is architectural rather than technical: stop asking the model to remember, and give the memory to the system that surrounds it."));
  out.push(bodyRuns([
    "All durable knowledge moves outside the model into a four-tier memory. ",
    { t: "Tier 0", bold: true },
    " is the active context window of 2,000 tokens, rebuilt from scratch for every single question. ",
    { t: "Tier 1", bold: true },
    " is the Story Spine, a fixed 650-token rolling master summary of the film that is injected verbatim into every turn. ",
    { t: "Tier 2", bold: true },
    " is the Structured State Store, a queryable external state of character dossiers, a timestamped event timeline, a scene index, and a motif ledger. ",
    { t: "Tier 3", bold: true },
    " is the Deep Archive of immutable evidence: the transcript, scene summaries, keyframe captions, and verbatim quotes. Each answer is produced from a freshly assembled window that combines the behavioral contract, the Spine, a small conversational scratchpad, a ranked slice of retrieved evidence, and the question itself. After each answer, a commit step writes the durable facts back to the store; roughly every twelve turns, a background consolidation pass rewrites the Spine under its fixed budget. Sessions may be refreshed at any moment, because nothing of value is ever left in volatile memory.",
  ]));
  out.push(body("The arithmetic that makes the design safe is straightforward. A two-hour film yields an analysis corpus of roughly 24,700 tokens, so a capped window holds only about 8 percent of what the system knows, which is precisely why retrieval rather than context growth carries the memory load. The key-value cache that a transformer must maintain for its context shrinks to roughly 0.28 GB at the fixed window, against roughly 18 GB at a 128,000-token context, a size that alone would exceed the entire 16 GB budget before any model weights were loaded. Under this architecture the complete answering stack, weights included, is budgeted near 8.6 GB with more than 7 GB of headroom. The refreshing of chat sessions stops being an act of forgetting and becomes a routine cache invalidation, with a durable copy always waiting on disk."));

  // ── 2. The Revised Operating Envelope ──
  out.push(h1("2. The Revised Operating Envelope"));
  out.push(h2("2.1 A Lighter Ingestion Profile"));
  out.push(body("The workflow changes begin at the front door. Instead of multi-gigabyte masters, the system now receives optimized uploads at 480p or 360p resolution, typically 500 to 600 MB per film. For a two-hour feature, a 550 to 600 MB file over roughly 118 minutes corresponds to a total bitrate of about 0.62 to 0.68 Mbps, squarely within the normal range for an efficient 480p encoding with a modest audio track. Nothing about the memory architecture depends on visual richness beyond what captioning requires, and 480p keyframes are fully legible for scene-boundary detection and description."));
  out.push(body("The downstream effects are almost entirely favorable. Uploads complete in minutes rather than hours, frame extraction produces smaller captures, and the derived artifact set shrinks accordingly: extracted audio near 0.10 GB, keyframe captures near 0.18 GB, and transcript artifacts that are negligible, for a peak disk footprint of about 0.94 GB, or just under 2 percent of the 50 GB scratch disk. Transcript quality is untouched by the downscaling, because automatic speech recognition works from the audio track, whose share of the bitrate is essentially unchanged between 360p and 1080p encodes. In short, the lighter profile reduces ingestion cost without reducing anything the memory system actually consumes."));
  out.push(h2("2.2 What the Free Tier Guarantees and What It Does Not"));
  out.push(body("Free Spaces provide two virtual CPU cores, 16 GB of RAM, 50 GB of ephemeral disk, and no accelerator. Two structural facts shape everything that follows. First, the disk is ephemeral: when the Space restarts or rebuilds, local files can vanish, so the durable memory tiers must be mirrored to a private dataset repository, with local disk treated as a warm cache that is always rehydratable from the remote copy. Second, with no GPU, inference runs on two CPU cores, so per-turn compute must be small and bounded, which is exactly what a fixed 2,000-token window guarantees: the cost of reading a prompt scales with its length, so capping the window caps the wait."));
  out.push(body("This blueprint therefore explicitly retires the companion document's GPU-tier recommendation for the answering path. Everything in the remainder of this document is CPU-only by construction, and the fixed window is reinterpreted not as a limitation to be endured but as the enabling condition for acceptable latency on free hardware. Table 1 summarizes the revised envelope."));
  out.push(tableCaption("Table 1. The lightweight operating envelope on the Hugging Face free tier"));
  out.push(makeTable(
    ["Parameter", "Lightweight profile", "Practical implication"],
    [
      ["Upload resolution", "480p or 360p video files", "Legible keyframes for captioning; speech recognition unaffected, since it is audio-driven"],
      ["Typical file size", "500-600 MB per two-hour film", "About 0.62-0.68 Mbps total bitrate; uploads take minutes, not hours"],
      ["Derived artifacts", "Audio, keyframes, transcript, state store", "Peak disk about 0.94 GB, roughly 2 percent of the 50 GB scratch disk"],
      ["Compute", "2 vCPU, CPU-only inference", "Bounded per-turn cost from the fixed window; answers in tens of seconds"],
      ["Durable memory", "Private dataset repository mirror", "Memory survives Space restarts and sleep; local disk is a rehydratable cache"],
    ],
    [20, 30, 50],
  ));

  // ── 3. The Core Dilemma ──
  out.push(h1("3. The Core Dilemma, Stated Precisely"));
  out.push(h2("3.1 What a 2,000-Token Window Can and Cannot Hold"));
  out.push(body("Two thousand tokens is approximately 1,500 English words, or about five book pages. That is the entire perceptual world of the model for any single answer. Against it stands the film: dialogue for a two-hour feature runs to roughly 8,400 to 11,500 words, about 13,300 tokens at the midpoint, and the full analysis corpus built on top of it, comprising scene summaries, character dossiers, motif ledgers, and free-form observations, totals roughly 18,600 words, or about 24,700 tokens. The fixed window therefore holds about 8 percent of the corpus, and even the bare transcript alone exceeds the window by a factor of nearly seven. No amount of clever packing fits the film into context; the architecture must select what enters, every single turn."));
  out.push(h2("3.2 Why Context Growth Is Rejected"));
  out.push(body("Growing the window with the conversation is rejected on three independent grounds. The first is raw memory: a transformer must hold a key-value cache for every token in its context, and this cache grows linearly. For a representative mid-size open-weights architecture with 36 transformer layers, 8 key-value attention heads, and 128-dimensional heads stored at half precision, each token of context costs about 144 KB. Two thousand tokens cost roughly 0.28 GB, which is trivial; 32,000 tokens cost about 4.5 GB, which is painful; 128,000 tokens cost about 18 GB, which alone exceeds the entire 16 GB budget before the roughly 5 GB of model weights are even counted. The crash the project fears is not hypothetical; it is the scheduled outcome of letting context grow."));
  out.push(body("The second ground is the visual token trap. Vision-language models spend hundreds of tokens representing a single image, so a modest batch of film frames can devour the entire window in one turn. The third ground is answer quality: long-context recall is statistically unreliable, with models demonstrably under-attending material buried in the middle of very long prompts, so stuffing context degrades the very continuity it is meant to preserve. A short, curated window keeps every turn sharp, grounded, and cheap enough for CPU-only inference. The fixed cap is thus simultaneously a memory guarantee, a quality decision, and the enabler of the free tier."));
  out.push(h2("3.3 Why Naive Session Reset Forgets"));
  out.push(body("A language model is stateless by construction: between calls it retains nothing, and the memory of a chat is an illusion produced by re-sending earlier turns inside the prompt. When that history is discarded to respect the 2,000-token ceiling, whatever was said is simply gone; the next question starts from a blank slate. This is the dilemma in its raw form, and it dissolves the moment ownership of memory changes. The conversation must not be the memory; it must be a pure transformation from an assembled window to an answer, while the system around the model holds the state and decides what each window contains. The goal stops being one long conversation that remembers and becomes an endless series of short conversations that each inherit a curated memory. Everything in Sections 4 through 7 is the machinery for making that inheritance reliable."));

  // ── 4. Architectural Stance ──
  out.push(h1("4. Architectural Stance: Five Governing Principles"));
  out.push(body("Five principles govern every component decision in this blueprint. They are stated here once and referenced throughout, because each one exists to foreclose a specific failure mode observed in fixed-context systems."));
  out.push(h2("Principle 1: The model is stateless; the system is stateful"));
  out.push(body("All durable memory lives outside the model process, on disk and in a remote durable repository. The 16 GB of RAM holds only the current turn's working set: model weights, the key-value cache for one small window, and retrieval caches. No conversation history, no accumulation, no background state in memory. A session that dies takes nothing with it that was committed, and nothing that was committed is ever lost to a refresh."));
  out.push(h2("Principle 2: Memory is text-mediated"));
  out.push(body("Vision runs exactly once, at ingestion, when frames are converted into captions and structured observations. Every interactive turn afterward is text-only. This single decision removes the largest token hazard in the system, because image inputs would otherwise consume hundreds of tokens each and a handful of frames could fill the whole window. It also lets the answering path run on a small, quantized, CPU-friendly model, since it never needs to look at pixels again."));
  out.push(h2("Principle 3: Budgets are hard caps, not guidelines"));
  out.push(body("Every slot in the 2,000-token window has a fixed allowance that is enforced at assembly time, before the model is invoked. When material exceeds its slot, the resolution is always to drop content, never to grow the window. The cap does not move at ten questions or at ten thousand; what changes is the ranking that decides which evidence earns its place."));
  out.push(h2("Principle 4: Commit before discard"));
  out.push(body("A session may be refreshed, interrupted, or killed at any time, but a turn is never considered finished until its durable facts have been extracted and appended to the external state. Once that commit has happened, discarding the window is lossless by construction, and the system is free to forget everything in RAM with total indifference."));
  out.push(h2("Principle 5: Summaries are derived caches; evidence is immutable ground truth"));
  out.push(body("The Story Spine and the scene summaries are regenerable: they can always be rebuilt from the underlying records and archive. The transcript and the captured observations are append-only and never rewritten. This asymmetry converts any apparent loss of memory into a cache miss with a known rebuild path, and it means the system's ground truth can never be corrupted by an error in one of its summaries."));

  return out;
};
