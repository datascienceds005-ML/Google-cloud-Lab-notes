// main2.js — assemble the Fixed-Context Rolling Memory blueprint docx
const H = require("../gen/helpers");
const {
  Document, Packer, Paragraph, TextRun, Header, Footer, PageNumber, NumberFormat,
  AlignmentType, SectionType, TableOfContents, fs, buildCoverR1, FONT_BODY, FONT_HEAD,
} = H;

const contentA = require("./content_a")(H);
const contentB = require("./content_b")(H);
const contentC = require("./content_c")(H);

const DOC_TITLE = "Fixed-Context Rolling Memory Architecture - Planning Blueprint";

const coverConfig = {
  englishLabel: "PLANNING BLUEPRINT",
  title: "Fixed-Context Rolling Memory Architecture",
  subtitle: "Sustaining Long-Horizon Movie Question Answering under a Permanently Capped 2,000-Token Window",
  metaLines: [
    "Deliverable: conceptual architecture and planning, strictly no code",
    "Target: Hugging Face free tier, 16 GB RAM, 50 GB ephemeral disk, no paid GPUs",
    "Companion to: Autonomous Movie Analysis - Planning Blueprint (November 2026)",
    "Prepared: November 2026",
  ],
  footerLeft: "Conceptual phase - memory architecture",
  footerRight: "November 2026",
};

function pageNumFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: FONT_BODY })],
    })],
  });
}
function docHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      border: { bottom: { style: "single", size: 2, color: "C8DDE2", space: 4 } },
      children: [new TextRun({ text: DOC_TITLE, size: 18, color: "808080", font: FONT_BODY })],
    })],
  });
}

const frontMatter = [
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 480, after: 360, line: 380, lineRule: "atLeast" },
    children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FONT_HEAD, color: "162235" })],
  }),
  new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-2" }),
  new Paragraph({
    spacing: { before: 200 },
    children: [new TextRun({
      text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
      italics: true, size: 18, color: "888888", font: FONT_BODY,
    })],
  }),
];

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

const doc = new Document({
  creator: "AI Systems Planning",
  title: DOC_TITLE,
  styles: {
    default: {
      document: {
        run: { font: FONT_BODY, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FONT_HEAD, size: 32, bold: true, color: "162235" },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FONT_HEAD, size: 30, bold: true, color: "162235" },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: FONT_HEAD, size: 28, bold: true, color: "162235" },
        paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: Cover
      properties: {
        page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
      },
      children: buildCoverR1(coverConfig),
    },
    { // Section 2: Front matter (TOC) — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin, pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageNumFooter() },
      children: frontMatter,
    },
    { // Section 3: Body — Arabic numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin, pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: docHeader() },
      footers: { default: pageNumFooter() },
      children: [...contentA, ...contentB, ...contentC],
    },
  ],
});

const OUT = "/home/z/my-project/download/Fixed_Context_Rolling_Memory_Blueprint.docx";
Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(OUT, buf);
  console.log("written", OUT, buf.length, "bytes");
});
