// content_b.js — Sections 5-7 of the Fixed-Context Rolling Memory blueprint
module.exports = (H) => {
  const { h1, h2, body, bodyRuns, tableCaption, figCaption, makeTable, figure } = H;
  const out = [];
  const A = "/home/z/my-project/scripts/assets";

  // ── 5. Four-Tier Architecture ──
  out.push(h1("5. The Four-Tier External Memory Architecture"));
  out.push(bodyRuns([
    "The memory of the system is organized into four tiers arranged by volatility and distance from the model. In the vocabulary of the project brief, the ",
    { t: "Rolling Memory", bold: true },
    " is Tiers 0 and 1: the active window and the Story Spine that rolls forward through the film. The ",
    { t: "External State", bold: true },
    " is Tiers 2 and 3: the durable, queryable stores that survive every refresh. Figure 1 shows the tiers and the five flows that connect them; the subsections that follow describe what each tier holds and why its capacity is what it is.",
  ]));
  out.push(figure(`${A}/mem_fig1_tiers.png`, 560));
  out.push(figCaption("Figure 1. The four-tier memory. The read path injects the Spine every turn and retrieves evidence per question; the write path commits facts per turn, consolidates periodically, and archives verbatim material."));

  out.push(h2("5.1 Tier 0: The Active Context Window"));
  out.push(body("The active window is the only content the model ever sees: 2,000 tokens, hard-capped, held in RAM, and rebuilt from scratch for every question. It is not a history and it is not a session; it is a per-turn assembly of a behavioral contract, a copy of the Story Spine, a small scratchpad of recent conversational context, a ranked slice of retrieved evidence, and the user's question, with reserved headroom for the answer. Because it is rebuilt each turn from durable material, its contents are reproducible: the same question against the same state yields the same window. Section 6 specifies its internal composition slot by slot."));
  out.push(h2("5.2 Tier 1: The Story Spine, the Rolling Memory"));
  out.push(body("The Story Spine is the system's rolling master summary: a fixed budget of roughly 650 tokens, about 490 words, that is injected verbatim into every window no matter how many turns have passed. Its structure is fixed so that its length never drifts: a one-sentence logline; a three-act map with one sentence per act; a roster of the eight principal characters, each reduced to who they are, what they want, and where their arc currently stands; the top five character relationships; the four or five dominant motifs with a one-line status each; a short list of open questions the analysis has raised; and a spoiler-state marker recording how far into the film the user's revealed progress extends."));
  out.push(body("The Spine is updated only by the background consolidation pass described in Section 7.3, never in the middle of a turn, so within any turn it is stable and identical to what the previous turn saw. Its fixed budget is the architectural guarantee of the whole design: the always-present layer of memory consumes a constant 2.6 percent of the analysis corpus regardless of how large the corpus grows, which is what allows the window cap to hold forever."));
  out.push(h2("5.3 Tier 2: The Structured State Store, the External State"));
  out.push(body("The State Store is the system's long-term memory proper: a durable, queryable collection of typed records. Character dossiers hold canonical names, aliases, relationships, and arc milestones, each with a timestamp. The event timeline holds one-line, timestamped entries in story order. The scene index holds one scene per entry with its timestamp range, a one-line summary, and its thematic tags. The motif ledger tracks each recurring symbol with the scenes in which it appears. Finally, a question-and-answer digest records what has already been asked and answered, which prevents both contradiction and tedious repetition across a long session."));
  out.push(body("Every record carries a pointer to its supporting evidence in the Deep Archive, so any claim in the store can be re-grounded in the transcript on demand. Records are appended after each answer by the commit step; nothing is ever deleted, and corrections supersede earlier values while leaving the superseded version in place. The store grows with the analysis, but it never enters the window whole: retrieval selects the slice relevant to the current question."));
  out.push(h2("5.4 Tier 3: The Deep Archive"));
  out.push(body("The Deep Archive is immutable, append-only evidence: the timestamped transcript, the full per-scene summaries, the keyframe captions, and the ingestion-time observations, together amounting to roughly 24,700 tokens for a typical feature. It is never injected whole. It serves two purposes: it is the source from which summaries are rebuilt, and it is the reservoir from which verbatim quotes are retrieved when an answer needs the film's own words. When an archive passage and a summary disagree, the archive wins by definition, and the summary is queued for correction at the next consolidation."));
  out.push(h2("5.5 How the Tiers Interact"));
  out.push(body("Five flows connect the tiers, and every one of them crosses the boundary between volatile and durable storage rather than accumulating inside it. Injection copies the Spine into every window. Retrieval selects evidence from the Store and Archive per question. Commit writes new durable facts from a finished answer back into the Store. Consolidation periodically rewrites the Spine from Store records. Archiving moves verbatim detail downward where it becomes immutable. Table 2 summarizes each tier's medium, capacity, cadence, and path into the window."));
  out.push(tableCaption("Table 2. The four tiers at a glance"));
  out.push(makeTable(
    ["Tier", "What it holds", "Capacity", "Update cadence", "Path into the window"],
    [
      ["Tier 0: Active window", "Contract, Spine copy, scratchpad, evidence, question", "2,000 tokens, hard cap", "Rebuilt for every turn", "It is the window"],
      ["Tier 1: Story Spine", "Logline, act map, cast roster, motifs, open threads, spoiler state", "Fixed at about 650 tokens", "Rewritten about every 12 turns", "Injected verbatim every turn"],
      ["Tier 2: State Store", "Character dossiers, event timeline, scene index, motif ledger, Q&A digest", "Grows with the analysis", "Appended after every answer", "Ranked slice retrieved per question"],
      ["Tier 3: Deep Archive", "Timestamped transcript, scene summaries, captions, verbatim quotes", "Full corpus, about 24,700 tokens", "Append-only at ingestion", "Excerpts retrieved on demand"],
    ],
    [17, 30, 17, 17, 19],
  ));

  // ── 6. Inside the Fixed Window ──
  out.push(h1("6. Inside the Fixed Window: The 2,000-Token Assembly"));
  out.push(body("The window is assembled, never accumulated. Before the model is invoked for any turn, the assembler builds the window from its fixed slots, checks every budget, and resolves overflow by dropping material rather than by growing. This is the enforcement point of Principle 3 and the reason the cap can be called permanent."));
  out.push(h2("6.1 Slot-by-Slot Composition"));
  out.push(body("Table 3 gives the allocation. The system contract carries the assistant's role, its refusal-handling stance for legitimate dark-fiction analysis, the answer-length rules, and the user's standing preferences. The Story Spine slot is a verbatim copy of Tier 1. The scratchpad is the small rolling note that gives the conversation continuity despite refreshes: the last few exchanges distilled to their gist, plus a pointer to the most recently mentioned entity, which is what lets a follow-up like asking why a character did something resolve to the right person without carrying the full history. The evidence slot holds the retrieved records and quotes for this specific question, and the answer headroom reserves space for the generation itself."));
  out.push(tableCaption("Table 3. The permanent 2,000-token window allocation"));
  out.push(makeTable(
    ["Slot", "Budget", "Typical content", "If over budget"],
    [
      ["System contract", "150", "Role, refusal stance, answer rules, user preferences", "Never grows; fixed text"],
      ["Story Spine", "650", "Rolling master summary, copied from Tier 1", "Never grows; fixed budget"],
      ["Recent-thread scratchpad", "120", "Last exchanges distilled, plus last-mentioned entity", "Oldest items are absorbed into the Store first"],
      ["Retrieved evidence", "700", "Store records and archive quotes matching the question", "Drop lowest-ranked items first"],
      ["User question", "80", "The question, lightly normalized", "Split into a follow-up turn"],
      ["Answer headroom", "300", "Space reserved for the generated answer", "Trade evidence down to raise it; cap still holds"],
      ["Total", "2,000", "Assembled fresh for every question", "The cap never moves"],
    ],
    [22, 13, 36, 29],
  ));
  out.push(body("The allocation is a dial, not a law of nature, and one deliberate variant is sanctioned. When the user asks for an extended analytical essay rather than a crisp answer, the assembler trades evidence down to about 480 tokens and raises the answer headroom to about 520, yielding answers near 390 words. The total remains exactly 2,000 in every case; the mix shifts, the cap does not."));
  out.push(h2("6.2 Overflow and Truncation Policy"));
  out.push(body("Only the evidence slot is expected to overflow in practice, and its truncation is deterministic. Candidate records are ranked by a blend of factors: entity match against the question's characters and motifs, timestamp proximity to the part of the film under discussion, thematic relevance per the scene index, and novelty against the question-and-answer digest, so the system prefers evidence it has not already cited. When the ranked list exceeds 700 tokens, the lowest-ranked items are dropped first, and the contract and Spine slots are never candidates for truncation. If retrieval returns nothing, because the question touches a corner of the film the ingestion passes did not characterize, the window simply runs under its cap, which is permitted: 2,000 tokens is a maximum, not a quota."));
  out.push(h2("6.3 Why Visual Tokens Never Enter the Window"));
  out.push(body("The exclusion of images from interactive turns deserves its own statement, because it is the decision that makes the entire budget realistic. A single 480p frame can cost a vision-language model as many tokens as the entire Story Spine, and a batch of six frames could consume the whole window before a word of the question was included. Under Principle 2, frames are looked at exactly once, at ingestion, when they become captions and structured observations; from then on the film exists for the answering path as text. Every turn is therefore cheap, bounded, and CPU-viable, and the 2,000-token ceiling bounds both RAM and per-turn compute simultaneously."));

  // ── 7. Session Lifecycle ──
  out.push(h1("7. The Session Lifecycle: Refreshing Without Forgetting"));
  out.push(body("The lifecycle of a single turn is a five-stage loop, shown in Figure 2. Its defining property is independence: each turn consumes only external state and produces only external state, so no turn is ever burdened by, or endangered by, the turns that came before it."));
  out.push(figure(`${A}/mem_fig2_lifecycle.png`, 560));
  out.push(figCaption("Figure 2. The commit-then-refresh loop. Solid arrows are the per-turn path; dashed arrows are the paths taken on the next question and during periodic background consolidation."));
  out.push(h2("7.1 The Turn Loop"));
  out.push(body("A turn begins with assembly, building the six-slot window from the durable tiers. The model then generates the answer from that window alone, holding to the reserved headroom. Next comes extraction, a lightweight scan of the exchange for anything durable: newly mentioned characters or aliases, newly established events, user preferences such as a spoiler ceiling, and any correction the user has just made. The commit stage appends the extracted facts, typically three to eight records, to the State Store, refreshes the scratchpad, and mirrors an updated snapshot toward the durable repository. Only then is the turn complete, and only then may the window be discarded."));
  out.push(h2("7.2 The Commit Step"));
  out.push(body("Commit is deliberately cheap so that it can run after every single answer even on two CPU cores, adding seconds rather than minutes. It is also deliberately transactional: records are appended to a local journal first, and the store snapshot is mirrored to the private dataset repository immediately afterward. If the Space dies between the two, recovery replays the journal; if it dies after, the remote snapshot already includes the turn. The worst case in every failure scenario is that one turn's facts must be re-derived from the answer that is about to be regenerated anyway."));
  out.push(body("Commit is also where precedence is settled. User corrections carry the highest precedence and immediately supersede conflicting store values, with the superseded value archived rather than erased, preserving the audit trail. Preferences such as answer length or spoiler tolerance are recorded at the same time, which is how the system honors a constraint stated fifty turns earlier without ever having carried it in context."));
  out.push(h2("7.3 Background Consolidation"));
  out.push(body("Every twelve turns, or sooner if the scratchpad is under pressure, the system runs its background summary pass, the mechanical heart of the rolling-memory idea. Consolidation rebuilds the Story Spine from State Store records rather than from the previous Spine text, which is what prevents the compounding drift that plagues summaries of summaries. Micro-facts accumulated since the last pass are merged into the roster, the act map, and the motif ledger; open questions that subsequent answers have resolved are removed; and any verbatim detail worth keeping is pushed down to the Deep Archive before the Spine is rewritten."));
  out.push(body("When the rebuild threatens the 650-token budget, eviction follows a fixed order: resolved open questions go first, then act-level detail that the scene index already covers, then the oldest motif commentary. The pass runs while the Space is idle, never during an answer, so its cost is latency-free from the user's perspective."));
  out.push(h2("7.4 Why Reset Is Now Safe"));
  out.push(body("The safety argument reduces to one invariant: at every commit boundary, everything needed for future answers exists in Tiers 1 through 3. Refreshing a session discards only the window, which is rebuilt deterministically from durable state at the next question. The same invariant extends across restarts and the free tier's sleep behavior: because the durable copy lives in the dataset repository rather than on the ephemeral disk, a cold-started Space rehydrates its caches from the repository and continues the analysis exactly where it left off. Session refreshing, initially the source of the memory dilemma, has been promoted to the design itself: short conversations over permanent state, instead of one fragile conversation trying to remember everything."));

  return out;
};
