"""Verify the generated blueprint: headings, tables, images, forbidden markers, code tokens."""
import re
import zipfile
from docx import Document

PATH = "/home/z/my-project/download/VLM_Movie_Analysis_Planning_Blueprint.docx"
doc = Document(PATH)

h1 = [p.text for p in doc.paragraphs if p.style.name == "Heading 1"]
h2 = [p.text for p in doc.paragraphs if p.style.name == "Heading 2"]
print("== H1 headings ==")
for t in h1:
    print("  ", t)
print("H1 count:", len(h1), "| H2 count:", len(h2), "| tables:", len(doc.tables))

words = sum(len(p.text.split()) for p in doc.paragraphs)
tbl_words = sum(len(c.text.split()) for t in doc.tables for r in t.rows for c in r.cells)
print("approx words (paragraphs):", words, "| (tables):", tbl_words)

with zipfile.ZipFile(PATH) as z:
    docxml = z.read("word/document.xml").decode("utf-8")
print("inline images:", docxml.count("<pic:pic"))

forbidden = ["XXX", "TODO", "待补充", "【", "undefined", "NaN", "TBD", "**", "|---", "```"]
full = "\n".join(p.text for p in doc.paragraphs) + "\n" + "\n".join(
    c.text for t in doc.tables for r in t.rows for c in r.cells)
hits = {m: full.count(m) for m in forbidden if m in full}
print("forbidden markers:", hits if hits else "none")

code_tokens = ["const ", "import ", "def ", "npm ", "pip install", "=>", "function(", "```",
               "python3", "sudo ", "```bash", ".py", ".js file", "for (", "while ("]
ctoks = {m: full.count(m) for m in code_tokens if m in full}
print("code-indicative tokens:", ctoks if ctoks else "none")

urls = re.findall(r"https?://\S+", full)
print("URLs mentioned:", urls)
