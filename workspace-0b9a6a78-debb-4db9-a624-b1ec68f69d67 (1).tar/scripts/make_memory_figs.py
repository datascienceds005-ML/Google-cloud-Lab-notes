"""Figures for the Fixed-Context Rolling Memory blueprint (English, teal palette
matching the companion blueprint's DM-1 scheme)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = "/home/z/my-project/scripts/assets"

DARK, TEAL, MID, PALE = "#162235", "#1B6B7A", "#4E93A3", "#A9C6CE"
CYAN, GRAY, PALE_BG = "#37DCF2", "#444444", "#EDF3F5"
ARROW_READ, ARROW_WRITE, ARROW_DASH = "#1B6B7A", "#5A6570", "#8AA6B0"

plt.rcParams["font.family"] = "DejaVu Sans"


def box(ax, x0, y0, x1, y1, fill, title, l2, l3=None, tcol="white", dashed=False, fs=10.5):
    ax.add_patch(FancyBboxPatch((x0, y0), x1 - x0, y1 - y0,
                 boxstyle="round,pad=0.02,rounding_size=0.08",
                 facecolor=fill, edgecolor=TEAL if dashed else "none",
                 linestyle=(0, (4, 3)) if dashed else "solid", linewidth=1.4))
    cy = (y0 + y1) / 2
    n = 2 + (l3 is not None)
    step = 0.30 if n == 3 else 0.24
    ax.text((x0 + x1) / 2, cy + step * (n - 1) / 2 * 0.9 + 0.06, title, ha="center", va="center",
            fontsize=fs, fontweight="bold", color=tcol)
    ax.text((x0 + x1) / 2, cy - 0.02, l2, ha="center", va="center", fontsize=8.3, color=tcol)
    if l3:
        ax.text((x0 + x1) / 2, cy - 0.38, l3, ha="center", va="center", fontsize=8.0,
                color=tcol, style="italic")


def arrow(ax, p, q, color, lw=2.0, dashed=False):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=16,
                 linewidth=lw, color=color, linestyle=(0, (5, 3)) if dashed else "solid",
                 shrinkA=0, shrinkB=0))


# ───────────────────────── Figure 1: four-tier memory architecture ─────────────────────────
fig, ax = plt.subplots(figsize=(11.6, 6.4), dpi=170, constrained_layout=True)
ax.set_xlim(0, 11.9); ax.set_ylim(0.6, 10.1); ax.axis("off")

tiers = [
    (4.2, 7.9, 7.8, 9.35, DARK, "TIER 0 - ACTIVE CONTEXT WINDOW",
     "2,000 tokens, hard cap - the only content the model sees",
     "RAM, volatile - rebuilt from scratch for every single question"),
    (3.4, 5.85, 8.6, 7.30, TEAL, "TIER 1 - STORY SPINE  (Rolling Memory)",
     "Fixed ~650-token master summary: logline, act map, character roster, motifs, open threads",
     "Fixed budget forever - rewritten by consolidation, never grown"),
    (2.6, 3.80, 9.4, 5.25, MID, "TIER 2 - STRUCTURED STATE STORE  (External State)",
     "Queryable records: character dossiers, timestamped timeline, scene index, motif ledger, Q&A digest",
     "Durable disk + remote repository - grows with analysis, sliced by retrieval"),
    (1.8, 1.75, 10.2, 3.20, PALE, "TIER 3 - DEEP ARCHIVE  (Immutable Evidence)",
     "Timestamped transcript, full scene summaries, keyframe captions, verbatim quotes, ingestion notes",
     "Append-only ground truth - never injected whole, always rebuildable source", DARK),
]
for x0, y0, x1, y1, fill, t, l2, l3, *tc in tiers:
    box(ax, x0, y0, x1, y1, fill, t, l2, l3, tcol=tc[0] if tc else "white")

# Read rail (left, upward) and write rail (right, downward)
arrow(ax, (0.95, 2.45), (0.95, 8.65), ARROW_READ, lw=2.4)
ax.text(0.52, 5.55, "READ PATH - inject Spine every turn, retrieve evidence per question",
        rotation=90, ha="center", va="center", fontsize=8.6, color=ARROW_READ, fontweight="bold")
arrow(ax, (10.95, 8.65), (10.95, 2.45), ARROW_WRITE, lw=2.4)
ax.text(11.48, 5.55, "WRITE PATH - commit facts per turn, consolidate periodically, archive verbatim",
        rotation=270, ha="center", va="center", fontsize=8.6, color=ARROW_WRITE, fontweight="bold")

ys = [8.62, 6.57, 4.52, 2.47]
lefts = [4.15, 3.35, 2.55, 1.75]
rights = [7.85, 8.65, 9.45, 10.25]
for y, xl in zip(ys, lefts):
    arrow(ax, (1.05, y), (xl, y), ARROW_READ, lw=1.5)
for y, xr in zip(ys, rights):
    arrow(ax, (xr, y), (10.85, y), ARROW_WRITE, lw=1.5)

fig.suptitle("Four-tier external memory architecture: Rolling Memory (Tier 0-1) plus External State (Tier 2-3)",
             fontsize=11.5, fontweight="bold", color=DARK)
fig.savefig(f"{OUT}/mem_fig1_tiers.png", facecolor="white")
plt.close(fig)

# ───────────────────────── Figure 2: turn lifecycle ─────────────────────────
fig, ax = plt.subplots(figsize=(12.2, 6.6), dpi=170, constrained_layout=True)
ax.set_xlim(0, 12.6); ax.set_ylim(0.2, 8.3); ax.axis("off")

steps = [
    (0.35, "1 - ASSEMBLE", "Build a fresh window: system contract, Story Spine,\nscratchpad, retrieved evidence, the question",
     "total strictly capped at 2,000 tokens"),
    (3.45, "2 - GENERATE", "The model answers from the window only;\nanswer held to about 300 tokens",
     "no state is kept inside the model"),
    (6.55, "3 - EXTRACT", "Scan the exchange for durable facts: entities,\nevents, user preferences, corrections",
     "a lightweight pass of seconds on CPU"),
    (9.65, "4 - COMMIT", "Append facts to the State Store, refresh the\nscratchpad, mirror a snapshot to the durable repo",
     "transactional: journal first, then remote copy"),
]
for x0, t, l2, l3 in steps:
    box(ax, x0, 5.55, x0 + 2.6, 7.45, TEAL, t, l2, l3)
for x in (3.05, 6.15, 9.25):
    arrow(ax, (x, 6.5), (x + 0.4, 6.5), DARK, lw=2.0)

box(ax, 4.55, 3.05, 8.05, 4.55, DARK, "5 - REFRESH (any time)",
    "Discard the active window entirely - safe by construction,\nbecause every durable fact already lives in external state",
    "next question simply re-assembles from disk", fs=10.0)
arrow(ax, (10.95, 5.55), (7.35, 4.60), DARK, lw=2.0)
arrow(ax, (4.55, 3.80), (1.65, 3.80), ARROW_DASH, lw=1.8, dashed=True)
arrow(ax, (1.65, 3.80), (1.65, 5.55), ARROW_DASH, lw=1.8, dashed=True)
ax.text(3.1, 4.02, "next question: re-assemble from external state", ha="center",
        fontsize=8.2, color="#5A7A86", style="italic")

box(ax, 8.9, 0.55, 12.25, 2.35, PALE_BG, "BACKGROUND - CONSOLIDATE  (every ~12 turns)",
    "Rebuild the Story Spine from State Store records; move verbatim\ndetail down to the Archive; re-enforce every fixed token budget",
    "runs while the Space is idle - never during an answer", tcol=DARK, dashed=True, fs=9.6)
arrow(ax, (10.6, 3.05), (10.6, 2.42), ARROW_DASH, lw=1.8, dashed=True)
ax.text(11.0, 2.72, "occasional", fontsize=7.8, color="#5A7A86", style="italic")
arrow(ax, (8.9, 1.45), (1.65, 1.45), ARROW_DASH, lw=1.8, dashed=True)
arrow(ax, (1.65, 1.45), (1.65, 5.55), ARROW_DASH, lw=1.8, dashed=True)
ax.text(5.2, 1.67, "updated Story Spine feeds the next assembly", ha="center",
        fontsize=8.2, color="#5A7A86", style="italic")

fig.suptitle("One question-answer turn: assemble, generate, extract, commit, then refresh without forgetting",
             fontsize=11.5, fontweight="bold", color=DARK)
fig.savefig(f"{OUT}/mem_fig2_lifecycle.png", facecolor="white")
plt.close(fig)

# verify non-blank
from PIL import Image
for name in ("mem_fig1_tiers", "mem_fig2_lifecycle"):
    im = Image.open(f"{OUT}/{name}.png").convert("L")
    h = im.histogram()
    print(name, im.size, "non-white ratio", round(1 - h[255] / sum(h), 3))
