"""Smoke test: run Layers 3-5 + memory + cleanup gate end-to-end with the
mock LLM (no network, no ffmpeg/cv2 needed). Verifies the 2,000-token
ceiling, the durable commit path, and the deletion gate logic.
"""
import json
import os
import pathlib
import py_compile
import sys
import tempfile

SPACE = "/home/z/my-project/download/movie-analysis-space"
os.environ["LLM_PROVIDER"] = "mock"
os.environ["DATA_DIR"] = tempfile.mkdtemp(prefix="mem_")
os.environ["SCRATCH_DIR"] = tempfile.mkdtemp(prefix="scratch_")
sys.path.insert(0, SPACE)

# 1) every module must compile
for p in sorted(pathlib.Path(SPACE).rglob("*.py")):
    py_compile.compile(str(p), doraise=True)
print("compile ok:", len(list(pathlib.Path(SPACE).rglob('*.py'))), "files")

from pipeline.cognition import build_initial_spine, build_story_schema  # noqa: E402
from pipeline.interaction import answer_question  # noqa: E402
from pipeline.memory import CleanupGate, MemoryStore  # noqa: E402

# 2) cognition over a synthetic transcript (2 chunks)
segments = [{"start": i * 30.0, "end": i * 30.0 + 25.0,
             "text": f"Scene {i}: ANNA argues with MARA about the lighthouse key "
                     f"while the beam sweeps the cliffs. [00:{i:02d}:00]"}
            for i in range(60)]
perception = {"transcript": segments,
              "captions": [{"t": 12.0, "text": "THE LIGHTHOUSE"}],
              "keyframes": [], "audio_path": "", "frames_dir": ""}

schema = build_story_schema(perception, log=print)
assert schema["characters"], "schema must contain characters"
spine = build_initial_spine(schema, log=print)

# 3) durable commit → all three tiers populated
store = MemoryStore("smoke-test", "Smoke Film")
store.commit_schema(schema, spine, perception["transcript"], perception["captions"])
sizes = store.tier_sizes()
print("tier sizes:", json.dumps(sizes))
assert sizes["tier1_story_spine"] > 0 and sizes["tier3_deep_archive"] > 0

# 4) cleanup gate: closed before commit is impossible here (we committed),
#    so it must open and delete the fake raw file
raw = pathlib.Path(os.environ["SCRATCH_DIR"]) / "source.mp4"
raw.write_bytes(b"x" * 1500)
res = CleanupGate(store).purge_raw_media([raw], log=print)
assert not raw.exists() and res["deleted"] == ["source.mp4"], res
print("gate:", res["status"])

# 5) Layer 5: window must respect the 2,000-token cap, answer + commit
answer, report = answer_question("Where does Anna first ask about the lighthouse key?", store)
total = report["sections"]["TOTAL"]
print("window report:", json.dumps(report["sections"]))
assert total <= report["cap"], f"window overflow: {total} > {report['cap']}"
assert answer.strip()
assert store.state["counters"]["qa_commits"] == 1
print("answer:", answer[:120])

# 6) second question — recent Q&A digest now flows into the window
answer2, report2 = answer_question("What motif recurs with the lighthouse beam?", store)
assert report2["sections"]["TOTAL"] <= report2["cap"]
assert store.state["qa_digest"], "Q&A digest must be committed"

print("\nSMOKE OK — window cap respected, tiers committed, gate open, 2 turns durable")
