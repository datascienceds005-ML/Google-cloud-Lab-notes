"""All arithmetic for the Fixed-Context Rolling Memory blueprint.
Every number printed here is the source of truth for the document text.
All estimates are labeled as estimates in the document itself."""
import json

R = {}

# ── 1. Token <-> word conversion (English prose, ~0.75 words per token) ──
WORDS_PER_TOKEN = 0.75
R["window_tokens"] = 2000
R["window_words"] = round(2000 * WORDS_PER_TOKEN)
R["window_pages_300w"] = round(R["window_words"] / 300, 1)

# ── 2. The 2,000-token window allocation (must sum exactly to 2000) ──
slots = [
    ("System contract", 150),
    ("Story Spine (rolling master summary)", 650),
    ("Recent-thread scratchpad", 120),
    ("Retrieved evidence slice", 700),
    ("User question", 80),
    ("Answer headroom", 300),
]
assert sum(b for _, b in slots) == 2000, sum(b for _, b in slots)
R["slots"] = [(n, b, round(b * WORDS_PER_TOKEN)) for n, b in slots]

# Deep-answer variant: trade evidence down, answer up
alt = [("System contract", 150), ("Story Spine", 650), ("Recent-thread scratchpad", 120),
       ("Retrieved evidence slice", 480), ("User question", 80), ("Answer headroom", 520)]
assert sum(b for _, b in alt) == 2000
R["alt_answer_tokens"] = 520
R["alt_answer_words"] = round(520 * WORDS_PER_TOKEN)

# ── 3. Corpus arithmetic for a representative ~2 h feature film ──
runtime_min = 118
speech_frac = 0.65          # share of runtime containing dialogue (estimate)
wpm_low, wpm_high = 110, 150
dialogue_words_low = round(runtime_min * speech_frac * wpm_low)
dialogue_words_high = round(runtime_min * speech_frac * wpm_high)
dialogue_words_mid = round((dialogue_words_low + dialogue_words_high) / 2)
R["dialogue_words"] = (dialogue_words_low, dialogue_words_mid, dialogue_words_high)

scenes = 45
scene_summary_words = 80
char_dossiers = 8
dossier_words = 160
ledger_words = 1200        # relationships, motif ledger, glossary (estimate)
notes_words = 2500         # ingestion observations, symbolic analysis notes (estimate)
scene_words = scenes * scene_summary_words
dossier_total = char_dossiers * dossier_words
corpus_words = dialogue_words_mid + scene_words + dossier_total + ledger_words + notes_words
corpus_tokens = round(corpus_words / WORDS_PER_TOKEN)
R["corpus"] = {
    "scene_words": scene_words, "dossier_total": dossier_total,
    "ledger_words": ledger_words, "notes_words": notes_words,
    "corpus_words": corpus_words, "corpus_tokens": corpus_tokens,
    "window_ratio_pct": round(2000 / corpus_tokens * 100, 1),
    "spine_ratio_pct": round(650 / corpus_tokens * 100, 1),
}
R["transcript_tokens_mid"] = round(dialogue_words_mid / WORDS_PER_TOKEN)

# ── 4. KV-cache arithmetic (illustrative mid-size open-weights architecture) ──
layers, kv_heads, head_dim, bytes_per_elem = 36, 8, 128, 2
per_token_bytes = 2 * kv_heads * head_dim * layers * bytes_per_elem   # K and V
kv_2k_gb = per_token_bytes * 2048 / 1024**3
kv_32k_gb = per_token_bytes * 32768 / 1024**3
kv_128k_gb = per_token_bytes * 131072 / 1024**3
R["kv"] = {
    "per_token_kb": round(per_token_bytes / 1024, 1),
    "at_2k_gb": round(kv_2k_gb, 2),
    "at_32k_gb": round(kv_32k_gb, 2),
    "at_128k_gb": round(kv_128k_gb, 2),
}

# ── 5. RAM budget during a Q&A turn (free CPU tier, estimates in GB) ──
ram = [
    ("Quantized 8B-class language model weights (4-bit)", 4.8),
    ("Inference runtime and framework overhead", 1.2),
    ("KV cache at the fixed 2,000-token window", round(kv_2k_gb, 1)),
    ("Retrieval index and state-store caches", 0.3),
    ("Operating system and process headroom", 2.0),
]
R["ram"] = {"rows": ram, "total_gb": round(sum(v for _, v in ram), 1),
            "headroom_gb": round(16.0 - sum(v for _, v in ram), 1)}

# ── 6. Upload profile: bitrate sanity for 480p / 360p ──
size_mb = 550.0
bitrate_550 = size_mb * 8 * 1000 * 1000 / (runtime_min * 60) / 1e6  # Mbps
size_600 = 600.0
bitrate_600 = size_600 * 8 * 1000 * 1000 / (runtime_min * 60) / 1e6
R["bitrate"] = {"mbps_550MB": round(bitrate_550, 2), "mbps_600MB": round(bitrate_600, 2)}

# ── 7. Disk arithmetic (50 GB ephemeral scratch) ──
disk_peak = {
    "Raw upload (480p, ~550-600 MB)": 0.60,
    "Extracted audio track": 0.10,
    "Adaptive keyframe set (480p captures)": 0.18,
    "Transcript and caption artifacts": 0.01,
    "Structured state store (durable copy mirrored off-Space)": 0.05,
}
disk_peak_total = round(sum(disk_peak.values()), 2)
steady = round(disk_peak_total - 0.60, 2)
R["disk"] = {"rows": disk_peak, "peak_gb": disk_peak_total,
             "steady_gb": steady, "pct_of_50gb": round(disk_peak_total / 50 * 100, 1)}

# ── 8. Session dynamics ──
R["consolidation"] = {
    "every_n_turns": 12,
    "scratchpad_budget": 120,
    "facts_per_turn_est": "3-8",
}
R["answers_per_session_window"] = "2,000-token window re-assembled per turn; history never accumulates"

print(json.dumps(R, indent=2))
