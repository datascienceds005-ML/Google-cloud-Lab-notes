"""Remove the duplicate first TOC entry that docx-js's TableOfContents field
keeps inside the field paragraph (add_toc_placeholders.py re-inserts the same
heading as the first visible placeholder entry)."""
import re
import shutil
import sys
import zipfile

path = sys.argv[1]
tmp = path + ".tmp"

with zipfile.ZipFile(path, "r") as zin:
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}

xml = data["word/document.xml"].decode("utf-8")

# The field paragraph: contains fldCharType="separate" followed by a hyperlink
# whose text duplicates the first injected TOC entry. Strip that hyperlink.
m = re.search(
    r'(<w:fldChar w:fldCharType="separate"/></w:r>)'
    r"(<w:hyperlink[^>]*>.*?</w:hyperlink>)",
    xml,
    flags=re.S,
)
if not m:
    print("no duplicate TOC entry found; nothing to do")
    sys.exit(0)

first_entry_text = re.search(r"<w:t[^>]*>([^<]*)</w:t>", m.group(2))
print("removing duplicate field-level entry:", first_entry_text.group(1) if first_entry_text else "?")
xml = xml[: m.start(2)] + xml[m.end(2):]
data["word/document.xml"] = xml.encode("utf-8")

with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
    for n in names:
        zout.writestr(n, data[n])
shutil.move(tmp, path)
print("done")
