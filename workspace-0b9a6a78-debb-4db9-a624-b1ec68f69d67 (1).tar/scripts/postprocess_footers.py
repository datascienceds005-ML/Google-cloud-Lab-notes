"""Post-process the generated docx for WPS/Word page-number compatibility.

1. Remove empty <w:pgNumType/> elements from document.xml (cover section).
2. Patch footer PAGE fields with explicit format switches, matching each
   section's pgNumType fmt: upperRoman -> \\* ROMAN, otherwise -> \\* arabic.
"""
import re
import shutil
import sys
import zipfile

path = sys.argv[1]
tmp = path + ".tmp"

with zipfile.ZipFile(path, "r") as zin:
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}

doc = data["word/document.xml"].decode("utf-8")

# 1. strip empty pgNumType
before = doc.count("<w:pgNumType/>")
doc = doc.replace("<w:pgNumType/>", "")

# 2. map each sectPr's footerReference to its intended number format
rels = data["word/_rels/document.xml.rels"].decode("utf-8")
rid_to_target = dict(re.findall(r'<Relationship[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"', rels))

sectprs = re.findall(r"<w:sectPr[ >].*?</w:sectPr>", doc, flags=re.S)
plan = {}  # footer xml part name -> switch text
for sp in sectprs:
    fmt_m = re.search(r'<w:pgNumType[^>]*w:fmt="([^"]+)"', sp)
    fmt = fmt_m.group(1) if fmt_m else "decimal"
    switch = "ROMAN" if "oman" in fmt or fmt.lower() == "upperroman" else "arabic"
    for rid in re.findall(r'<w:footerReference[^>]*r:id="([^"]+)"', sp):
        target = rid_to_target.get(rid, "")
        part = "word/" + target.lstrip("/") if not target.startswith("word/") else target
        if part in data:
            plan[part] = switch

patched = []
for part, switch in plan.items():
    xml = data[part].decode("utf-8")
    new_xml, n = re.subn(
        r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
        r"\1 PAGE \\* " + switch + r" \\* MERGEFORMAT \2",
        xml,
    )
    if n:
        data[part] = new_xml.encode("utf-8")
        patched.append((part, switch, n))

data["word/document.xml"] = doc.encode("utf-8")

with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
    for n in names:
        zout.writestr(n, data[n])
shutil.move(tmp, path)

print(f"removed {before} empty pgNumType; patched footers: {patched}")
