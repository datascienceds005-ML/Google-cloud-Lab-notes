import asyncio
import os
from playwright.async_api import async_playwright

HTML = '/home/z/my-project/scripts/pipeline_architecture.html'
OUT = '/home/z/my-project/download/Movie_Analysis_Pipeline_Architecture.png'


async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page(viewport={'width': 1500, 'height': 900},
                                      device_scale_factor=2)
        await page.goto(f'file://{HTML}', wait_until='networkidle')
        await page.wait_for_timeout(500)

        el = page.locator('#root')
        bbox = await el.bounding_box()
        if bbox:
            fit_w = max(1500, int(bbox['width'] + 100))
            fit_h = int(bbox['height'] + 100)
            await page.set_viewport_size({'width': fit_w, 'height': fit_h})
            await page.wait_for_timeout(300)
        await el.screenshot(path=OUT)
        await browser.close()
        print(f'saved {OUT} ({os.path.getsize(OUT) / 1024:.0f} KB)')


asyncio.run(main())
