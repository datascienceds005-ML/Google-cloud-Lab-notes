"""Generate the two charts embedded in the VLM movie-analysis planning blueprint."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ACCENT = "#1B6B7A"      # DM-1 table accent (darkened cyan, safe on white)
GRAY = "#B0B0B0"
RED = "#B87472"          # Morandi red for the "delete me" raw file
TXT = "#303030"

plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["text.color"] = TXT
plt.rcParams["axes.labelcolor"] = TXT
plt.rcParams["xtick.color"] = TXT
plt.rcParams["ytick.color"] = TXT

# ---------------------------------------------------------------
# Figure 1: approximate weight memory at 16-bit vs 4-bit
# Pure arithmetic: params x 2 bytes (16-bit) vs params x 0.5 bytes (4-bit)
# ---------------------------------------------------------------
models = [
    ("Gemma 3 12B", 24.0),
    ("Llama 3.2 11B Vision", 22.0),
    ("Qwen3-VL-8B", 16.0),
    ("MiniCPM-V 4.5 (8B)", 16.0),
    ("Qwen2.5-VL-7B", 14.0),
    ("Qwen3-VL-4B", 8.0),
]
labels = [m[0] for m in models]
fp16 = [m[1] for m in models]
int4 = [round(m[1] / 4.0, 1) for m in models]  # 4x compression vs 16-bit

fig, ax = plt.subplots(figsize=(10, 5.2), constrained_layout=True)
y = range(len(models))
h = 0.38
b1 = ax.barh([i + h / 2 for i in y], fp16, height=h, color=GRAY, label="16-bit weights (estimate)")
b2 = ax.barh([i - h / 2 for i in y], int4, height=h, color=ACCENT, label="4-bit weights (estimate)")
ax.axvline(16, color=RED, linestyle="--", linewidth=1.4)
ax.text(16.15, len(models) - 0.45, "16 GB memory ceiling", color=RED, fontsize=9, va="top")
ax.set_yticks(list(y))
ax.set_yticklabels(labels)
ax.invert_yaxis()
ax.set_xlabel("Approximate weight memory (GB) - weights only, excludes KV cache and runtime overhead")
ax.set_title("Model weight memory at 16-bit vs 4-bit precision (parameter-count estimates)", fontsize=11)
for bars in (b1, b2):
    for rect in bars:
        w = rect.get_width()
        ax.text(w + 0.25, rect.get_y() + rect.get_height() / 2, f"{w:g}", va="center", fontsize=8.5)
ax.set_xlim(0, 27)
ax.grid(True, axis="x", alpha=0.3)
ax.legend(loc="lower right", fontsize=9)
fig.savefig("/home/z/my-project/scripts/assets/fig1_memory.png", dpi=200)
plt.close(fig)

# ---------------------------------------------------------------
# Figure 2: storage footprint per processed film (illustrative)
# ---------------------------------------------------------------
items = [
    ("Raw 1080p movie file (2-4 GB) - deleted after processing", 3000),
    ("Keyframe images, approx. 450 JPEG stills", 120),
    ("Extracted audio track", 100),
    ("Embedding index for semantic retrieval", 30),
    ("Dense frame captions (text)", 3),
    ("Story schema and scene index (text)", 2),
    ("Timestamped dialogue transcript (text)", 0.5),
]
labels2 = [i[0] for i in items]
vals = [i[1] for i in items]
colors = [RED] + [ACCENT] * (len(items) - 1)

fig, ax = plt.subplots(figsize=(10, 5.2), constrained_layout=True)
y2 = range(len(items))
bars = ax.barh(list(y2), vals, color=colors, height=0.55)
ax.set_xscale("log")
ax.set_yticks(list(y2))
ax.set_yticklabels(labels2, fontsize=9)
ax.invert_yaxis()
for rect, v in zip(bars, vals):
    lab = f"{v:g} MB" if v >= 1 else f"{int(v * 1000)} KB"
    ax.text(rect.get_width() * 1.15, rect.get_y() + rect.get_height() / 2, lab,
            va="center", fontsize=8.5)
ax.set_xlim(0.3, 12000)
ax.set_xlabel("Megabytes, logarithmic scale (illustrative estimates for a roughly 2-hour film)")
ax.set_title("Storage footprint: raw file vs retained artifacts after processing", fontsize=11)
ax.grid(True, axis="x", alpha=0.3)
fig.savefig("/home/z/my-project/scripts/assets/fig2_storage.png", dpi=200)
plt.close(fig)

print("charts done")
