---
title: Movie Dubber Simple
emoji: 🎬
colorFrom: blue
colorTo: purple
sdk: streamlit
sdk_version: 1.32.0
app_file: app.py
pinned: false
---

# Movie Dubber

Translate and dub videos from English to Hindi.