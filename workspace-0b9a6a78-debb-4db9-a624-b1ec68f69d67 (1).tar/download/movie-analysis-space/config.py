"""Central configuration for the Movie Analysis & Fixed-Context Memory pipeline.

Every knob is overridable via environment variables (Spaces secrets / vars),
so the same code runs on any free CPU Space without edits.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

# ── Storage ──────────────────────────────────────────────────────────────
# Durable tier files (Tiers 1-3). On a free Space this disk is ephemeral:
# set DATASET_REPO + HF_TOKEN to mirror snapshots and survive restarts.
DATA_DIR = Path(os.getenv("DATA_DIR", str(BASE_DIR / "data")))
# Ephemeral scratch for raw media (video / audio / frames).
# Purged by the cleanup gate after the durable commit.
SCRATCH_DIR = Path(os.getenv("SCRATCH_DIR", "/tmp/movie_scratch"))

# ── Tier 0: fixed-context active window ─────────────────────────────────
ACTIVE_WINDOW_TOKENS = int(os.getenv("ACTIVE_WINDOW_TOKENS", "2000"))
SPINE_TOKENS = int(os.getenv("SPINE_TOKENS", "650"))
QA_DIGEST_WINDOW = int(os.getenv("QA_DIGEST_WINDOW", "6"))        # kept in state
QA_DIGEST_IN_WINDOW = 3                                           # shown per question
SPINE_REFRESH_EVERY = int(os.getenv("SPINE_REFRESH_EVERY", "5"))  # Q&A commits
ANSWER_MAX_TOKENS = int(os.getenv("ANSWER_MAX_TOKENS", "512"))

# ── Layer 2: Perception (CPU only) ───────────────────────────────────────
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "small")      # tiny | base | small | medium
WHISPER_COMPUTE = os.getenv("WHISPER_COMPUTE", "int8")   # int8 is the CPU sweet spot
FRAME_SCAN_FPS = float(os.getenv("FRAME_SCAN_FPS", "2"))  # shot-detector scan rate
SHOT_THRESHOLD = float(os.getenv("SHOT_THRESHOLD", "0.35"))  # 1 - HSV histogram correlation
MAX_KEYFRAMES = int(os.getenv("MAX_KEYFRAMES", "120"))
KEYFRAME_HEIGHT = int(os.getenv("KEYFRAME_HEIGHT", "480"))
OCR_ENABLED = os.getenv("OCR_ENABLED", "1") == "1"

# ── LLM (Layer 3 Cognition / Layer 5 Interaction) ────────────────────────
# hf_inference : free serverless Inference API (needs the HF_TOKEN secret)
# local        : transformers on CPU (add torch + transformers to requirements)
# mock         : deterministic stub, no network — for pipeline tests
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "hf_inference")
HF_LLM_MODEL = os.getenv("HF_LLM_MODEL", "Qwen/Qwen2.5-7B-Instruct")
LOCAL_LLM_MODEL = os.getenv("LOCAL_LLM_MODEL", "Qwen/Qwen2.5-1.5B-Instruct")
HF_TOKEN = os.getenv("HF_TOKEN") or os.getenv("HUGGINGFACE_API_KEY") or ""
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.2"))

# ── Optional durable mirror (Tier 2/3 snapshots) ─────────────────────────
DATASET_REPO = os.getenv("DATASET_REPO", "").strip()   # e.g. "yourname/movie-memory"
AUTO_SYNC = os.getenv("AUTO_SYNC_TO_REPO", "1") == "1"
