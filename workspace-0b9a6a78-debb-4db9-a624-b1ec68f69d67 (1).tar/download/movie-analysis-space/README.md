---
title: Movie Analysis Pipeline
emoji: 🎬
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: 4.44.1
python_version: "3.11"
app_file: app.py
pinned: false
---

# Movie Analysis Pipeline — Fixed-Context Rolling Memory

Autonomous movie Q&A on a **free CPU Space**. Upload a lightweight 480p/360p
encode (~0.5-0.6 GB); the 5-layer pipeline turns it into a queryable story
memory that answers questions through a **hard-capped 2,000-token window** —
no fine-tuning, no GPU, no context overflow.

| Layer | Stage | What runs (all CPU) |
|---|---|---|
| 1 | **Ingest** | Upload registered on scratch disk, probed with ffprobe |
| 2 | **Perception** | Shot-boundary keyframes (OpenCV) · dialogue transcript (faster-whisper int8) · caption OCR (Tesseract) |
| 3 | **Cognition** | Automated story schema: characters, timestamped scene index, motifs, open threads |
| 4 | **Memory** | 4-tier external store + window assembler + cleanup gate |
| 5 | **Interaction** | Q&A from a freshly assembled window; commit-then-refresh |

## Memory architecture (4 tiers + gate)

- **Tier 0 — Active Window** *(volatile, per turn)*: hard cap **2,000 tokens**.
  Rebuilt from scratch for every question: Story Spine → recent Q&A digest →
  question-matched Tier 2 records → verbatim Tier 3 hits on a miss → the
  question. Nothing carries over between turns.
- **Tier 1 — Story Spine** *(durable)*: rolling ≤650-token master summary,
  re-summarized automatically every 5 Q&A commits.
- **Tier 2 — State Store** *(durable, queryable)*: character dossiers,
  timestamped scene index, motif ledger, open threads, Q&A digest.
- **Tier 3 — Deep Archive** *(durable, immutable)*: verbatim transcript and
  caption cards, rehydrated only when the State Store misses.
- **Cleanup gate** *(automatic)*: once records are committed to Tiers 1-3,
  raw video/audio/frames are erased from scratch disk (~1 GB freed per film)
  and every deletion is logged.

## Quick start

1. Upload all files in this folder to the Space (keeping the layout).
2. Space **Settings → Variables and secrets** → add the secret `HF_TOKEN`
   (your write-enabled HF token). The LLM runs on the free serverless
   Inference API, so the Space itself stays CPU-only.
3. Open the Space → tab **① Ingest & Analyze** → upload a film → wait for the
   batch to finish → ask questions in tab **② Ask the Movie**.

## Configuration (Settings → Variables and secrets)

| Variable | Type | Default | Purpose |
|---|---|---|---|
| `HF_TOKEN` | secret | — | **Required** — Inference API + dataset mirror |
| `DATASET_REPO` | variable | — | e.g. `yourname/movie-memory`; mirrors tier snapshots so memory survives restarts |
| `LLM_PROVIDER` | variable | `hf_inference` | `hf_inference` / `local` / `mock` |
| `HF_LLM_MODEL` | variable | `Qwen/Qwen2.5-7B-Instruct` | any chat model on the serverless API |
| `WHISPER_MODEL` | variable | `small` | `base` is ~2× faster, `medium` more accurate |
| `ACTIVE_WINDOW_TOKENS` | variable | `2000` | Tier 0 hard cap |
| `SPINE_TOKENS` | variable | `650` | Tier 1 budget |
| `MAX_KEYFRAMES` | variable | `120` | keyframe cap for OCR |
| `OCR_ENABLED` | variable | `1` | set `0` to skip Tesseract |
| `AUTO_SYNC_TO_REPO` | variable | `1` | mirror after every commit |

## Durability on the free tier

The Space disk is ephemeral. Durable state = the tier files
(`data/<film_id>/spine.md`, `state.json`, `archive.json`). With
`DATASET_REPO` + `HF_TOKEN` set, they are mirrored after analysis and after
every Q&A commit, and `RepoSync.restore()` reloads them on startup. Raw media
is never persisted — the cleanup gate deletes it by design.

## Python version note

`python_version: 3.11` in the YAML above pins the Space off the Python 3.13
default, because Python 3.13 removed the stdlib `audioop` module that pydub
(a Gradio dependency) imports at startup. As a fallback, `requirements.txt`
also installs `audioop-lts` — but only when the interpreter is 3.13+ — so the
Space builds cleanly either way.

## Testing without any LLM quota

Set `LLM_PROVIDER=mock` and the full pipeline runs end-to-end with a
deterministic stub (no network) — useful to verify wiring before spending
Inference API quota. `LLM_PROVIDER=local` runs a small chat model on CPU
(add `torch` + `transformers` to `requirements.txt`).

## Runtime expectations (free 2-vCPU tier)

A 90-minute film: transcription dominates — `small`/int8 ≈ 20-45 min,
`base`/int8 ≈ 10-25 min; schema building adds one LLM call per ~3.5k-char
transcript chunk. Q&A latency is a single windowed LLM call (~5-20 s).
