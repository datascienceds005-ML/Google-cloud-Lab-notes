"""Movie Analysis Pipeline — Gradio UI.

Tabs: ① Ingest & Analyze (5-layer batch, streamed log)
      ② Ask the Movie (Layer 5, fresh 2,000-token window per question)
      ③ Memory Inspector (tier sizes, spine, cleanup-gate log)
      ④ Admin (dataset mirror, new session)

Free-tier friendly: one film at a time, one analysis at a time (lock),
all heavy work queued by Gradio.
"""
import json
import queue
import threading

import gradio as gr

from config import (ACTIVE_WINDOW_TOKENS, DATASET_REPO, HF_LLM_MODEL,
                    HF_TOKEN, LLM_PROVIDER, WHISPER_MODEL)
from pipeline.interaction import answer_question
from pipeline.orchestrator import analyze_movie, get_store
from pipeline.memory import RepoSync

CURRENT = {"film_id": None}

HEADER = f"""
# 🎬 Movie Analysis Pipeline
**Layer 1** Ingest → **Layer 2** Perception → **Layer 3** Cognition → **Layer 4** Memory → **Layer 5** Interaction
Fixed **{ACTIVE_WINDOW_TOKENS}-token** active window · 4-tier rolling memory · automatic raw-file deletion gate
"""

HOW_IT_RUNS = """
**What this batch does (unattended, CPU only):**
1. **Ingest** — registers your 480p/360p upload on scratch disk (ffprobe).
2. **Perception** — shot-boundary keyframes (OpenCV) · dialogue transcript (faster-whisper int8) · caption OCR (Tesseract).
3. **Cognition** — builds the story schema: characters, timestamped scene index, motifs, open threads + the 650-token Story Spine.
4. **Memory** — commits Tiers 1-3; the **cleanup gate** then erases all raw media from scratch.
5. Ready — ask questions in tab ②; every answer uses a fresh 2,000-token window.

A 90-minute film ≈ 20-45 min on the free 2-vCPU tier (`WHISPER_MODEL=base` roughly halves it).
"""

ENV_MD = f"""
### Runtime configuration
| Setting | Value | How to change |
|---|---|---|
| LLM provider | `{LLM_PROVIDER}` | var `LLM_PROVIDER`: `hf_inference` / `local` / `mock` |
| LLM model | `{HF_LLM_MODEL}` | var `HF_LLM_MODEL` |
| Whisper | `{WHISPER_MODEL}` int8 CPU | var `WHISPER_MODEL`: tiny / base / small |
| Dataset mirror | `{DATASET_REPO or 'not configured'}` | var `DATASET_REPO` + secret `HF_TOKEN` |
| HF token present | `{'yes' if HF_TOKEN else 'no'}` | secret `HF_TOKEN` |

Tier files live in `data/<film_id>/` and are mirrored to the dataset repo after
analysis and after every Q&A commit — that is what survives a Space restart.
"""


def run_analysis(file, title):
    if not file:
        yield "⚠ Upload a lightweight 480p/360p video first."
        return
    q: queue.Queue = queue.Queue()
    result = {}

    def log(msg):
        q.put(str(msg))

    def worker():
        try:
            result["ok"] = analyze_movie(file, title, log=log)
        except Exception as e:  # noqa: BLE001 — show everything in the log pane
            result["err"] = f"{type(e).__name__}: {e}"
        finally:
            q.put(None)

    threading.Thread(target=worker, daemon=True).start()
    lines = []
    while True:
        item = q.get()
        if item is None:
            break
        lines.append(item)
        yield "\n".join(lines)
    if "err" in result:
        lines.append(f"❌ {result['err']}")
        yield "\n".join(lines)
        return
    film_id, summary = result["ok"]
    CURRENT["film_id"] = film_id
    lines.append("\n" + json.dumps(summary, indent=2))
    yield "\n".join(lines)


def chat_answer(message, history):
    history = list(history or [])
    if not message.strip():
        yield history, ""
        return
    if not CURRENT["film_id"]:
        history += [{"role": "user", "content": message},
                    {"role": "assistant",
                     "content": "⚠ No film analyzed yet — upload one in tab ① first."}]
        yield history, ""
        return
    history += [{"role": "user", "content": message}]
    yield history, ""
    store = get_store(CURRENT["film_id"])
    answer, report = answer_question(message, store)
    history += [{"role": "assistant", "content": answer}]
    yield history, json.dumps(report["sections"], indent=2)


def inspect_memory():
    if not CURRENT["film_id"]:
        return "No film loaded. Run tab ① first."
    store = get_store(CURRENT["film_id"])
    s = store.tier_sizes()
    st = store.state
    return "\n".join([
        f"**film_id:** `{store.film_id}` · **title:** {store.title}",
        "",
        f"**Tier 0 — Active Window:** cap {s['tier0_active_window_cap']} tokens "
        "(volatile, rebuilt per question, never persisted)",
        f"**Tier 1 — Story Spine:** {s['tier1_story_spine']} tokens",
        f"**Tier 2 — State Store:** {s['tier2_state_store']} tokens · "
        f"{len(st['characters'])} characters · {len(st['scenes'])} scene beats · "
        f"{len(st['motifs'])} motifs · {len(st['threads'])} threads · "
        f"{st['counters'].get('qa_commits', 0)} Q&A commits",
        f"**Tier 3 — Deep Archive:** {s['tier3_deep_archive']} tokens · "
        f"{len(store.archive['transcript'])} transcript segments · "
        f"{len(store.archive['captions'])} caption cards",
        "",
        "### Tier 1 — Story Spine (verbatim)",
        store.spine or "—",
        "",
        "### Cleanup gate log",
        "```",
        store.cleanup_log().strip(),
        "```",
    ])


def force_sync():
    if not CURRENT["film_id"]:
        return "Nothing to sync — no film loaded."
    return RepoSync(get_store(CURRENT["film_id"])).sync()


def new_session():
    CURRENT["film_id"] = None
    return "Session cleared. The tier files stay on disk (and in the dataset repo)."


with gr.Blocks(title="Movie Analysis Pipeline") as demo:
    gr.Markdown(HEADER)

    with gr.Tab("① Ingest & Analyze"):
        file_in = gr.File(label="Movie file — lightweight 480p/360p encode, ~0.5-0.6 GB",
                          file_types=[".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v"],
                          type="filepath")
        title_in = gr.Textbox(label="Film title (optional — used as the memory key)",
                              placeholder="e.g. The Lighthouse")
        run_btn = gr.Button("Run full pipeline (CPU — unattended)", variant="primary")
        log_out = gr.Textbox(label="Pipeline log", lines=20)
        gr.Markdown(HOW_IT_RUNS)

    with gr.Tab("② Ask the Movie"):
        chat = gr.Chatbot(label="Q&A — every turn is a fresh 2,000-token window",
                          type="messages", height=420)
        msg_in = gr.Textbox(show_label=False, placeholder="e.g. Why does Anna need the key before dawn?")
        window_out = gr.Textbox(label="Last window assembly (tokens per section)", lines=6)
        clear_btn = gr.Button("Clear chat")

    with gr.Tab("③ Memory Inspector"):
        insp_btn = gr.Button("Refresh")
        insp_out = gr.Markdown(inspect_memory)

    with gr.Tab("④ Admin"):
        gr.Markdown(ENV_MD)
        repo_btn = gr.Button("Force sync tiers → dataset repo")
        repo_out = gr.Textbox(label="Result", lines=2)
        new_btn = gr.Button("Start new session (drop current film from RAM)")
        new_out = gr.Textbox(label="Result", lines=2)

    run_btn.click(run_analysis, [file_in, title_in], log_out)
    msg_in.submit(chat_answer, [msg_in, chat], [chat, window_out]).then(
        lambda: "", None, msg_in)
    clear_btn.click(lambda: ([], ""), None, [chat, window_out])
    insp_btn.click(inspect_memory, None, insp_out)
    demo.load(inspect_memory, None, insp_out)
    repo_btn.click(force_sync, None, repo_out)
    new_btn.click(new_session, None, new_out)

if __name__ == "__main__":
    demo.queue(max_size=8).launch()
