"""Layer 3 — Cognition.

Builds the automated story schema from perception artifacts — the only
LLM-heavy stage of ingest, and it runs once per film:
  * character roster (name, aliases, one-line description),
  * timestamped scene index (events with start / end seconds),
  * motif ledger and open-thread list,
  * the initial 650-token Story Spine (Tier 1).
"""
import json

from config import SPINE_TOKENS
from pipeline.llm import extract_json, get_llm
from pipeline.tokens import clip_to_tokens, count_tokens

CHUNK_CHARS = 3500
MAX_CHARACTERS = 60
MAX_MOTIFS = 40
MAX_THREADS = 30

EXTRACT_PROMPT = """You are building a story schema for a movie from part {i}/{n} of its dialogue transcript.
Return ONLY valid JSON with this exact shape:
{{"characters": [{{"name": "...", "aliases": ["..."], "description": "one sentence"}}],
  "events": [{{"start": 12.3, "end": 96.0, "summary": "one sentence", "characters": ["..."]}}],
  "motifs": ["short motif phrase"],
  "threads": ["open question or unresolved thread"]}}
Rules: use the transcript times (seconds) for events; omit empty lists; no commentary.

TRANSCRIPT PART {i}:
{chunk}"""

SPINE_PROMPT = """Compress the movie story schema below into a master summary of AT MOST {tok} tokens.
Include: logline, three-act map, main characters with one-line descriptions, key motifs, open threads.
Plain text only, no headings, no commentary.

{schema}

MASTER SUMMARY:"""

REFRESH_PROMPT = """Rewrite the movie memory below into a fresh master summary of AT MOST {tok} tokens.
Keep the logline, act map, main characters, key motifs and open threads, folding in the newest Q&A facts.
Plain text only, no headings, no commentary.

CURRENT MEMORY:
{state}

MASTER SUMMARY:"""


def chunk_transcript(segments: list, max_chars: int = CHUNK_CHARS) -> list:
    chunks, cur, cur_len = [], [], 0
    for seg in segments:
        if cur and cur_len + len(seg["text"]) > max_chars:
            chunks.append({"start": cur[0]["start"], "end": cur[-1]["end"],
                           "text": " ".join(s["text"] for s in cur)})
            cur, cur_len = [], 0
        cur.append(seg)
        cur_len += len(seg["text"])
    if cur:
        chunks.append({"start": cur[0]["start"], "end": cur[-1]["end"],
                       "text": " ".join(s["text"] for s in cur)})
    return chunks


def _norm_events(raw) -> list:
    events = []
    for e in raw or []:
        try:
            start, end = float(e.get("start", 0)), float(e.get("end", 0))
        except (TypeError, ValueError):
            continue
        events.append({"start": start, "end": max(end, start),
                       "summary": str(e.get("summary", "")).strip(),
                       "characters": [str(c) for c in e.get("characters", [])][:8]})
    return events


def _merge_characters(dst: list, src: list) -> None:
    for ch in src or []:
        name = str(ch.get("name", "")).strip()
        if not name:
            continue
        aliases = {a.casefold() for a in ch.get("aliases", []) if a}
        desc = str(ch.get("description", "")).strip()
        for existing in dst:
            if existing["name"].casefold() == name.casefold() \
                    or name.casefold() in {a.casefold() for a in existing["aliases"]}:
                existing["aliases"] = sorted({*existing["aliases"], *ch.get("aliases", []),
                                              name} - {existing["name"]})[:8]
                if len(desc) > len(existing["description"]):
                    existing["description"] = desc
                break
        else:
            dst.append({"name": name, "aliases": sorted(aliases)[:8], "description": desc})
        if len(dst) >= MAX_CHARACTERS:
            return


def extract_chunk_schema(chunk: dict, idx: int, total: int, llm) -> dict:
    try:
        reply = llm.chat("Reply with JSON only.",
                         EXTRACT_PROMPT.format(i=idx, n=total, chunk=chunk["text"]),
                         max_tokens=900)
        return extract_json(reply)
    except Exception as e:  # noqa: BLE001 — one bad chunk must not kill the film
        print(f"  ⚠ schema extraction failed for part {idx}: {e}")
        return {}


def build_story_schema(perception: dict, log=print) -> dict:
    llm = get_llm()
    chunks = chunk_transcript(perception["transcript"])
    if not chunks:
        raise RuntimeError("empty transcript — cannot build a story schema "
                           "(was there any dialogue audio?)")
    log(f"  transcript split into {len(chunks)} chunks (~{CHUNK_CHARS} chars each)")

    schema = {"characters": [], "events": [], "motifs": [], "threads": []}
    for i, ch in enumerate(chunks, 1):
        log(f"  schema pass {i}/{len(chunks)} ({ch['start']:.0f}s–{ch['end']:.0f}s)")
        part = extract_chunk_schema(ch, i, len(chunks), llm)
        _merge_characters(schema["characters"], part.get("characters"))
        schema["events"].extend(_norm_events(part.get("events")))
        for m in part.get("motifs", []):
            m = str(m).strip()
            if m and m.casefold() not in {x.casefold() for x in schema["motifs"]}:
                schema["motifs"].append(m)
        for t in part.get("threads", []):
            t = str(t).strip()
            if t and t.casefold() not in {x.casefold() for x in schema["threads"]}:
                schema["threads"].append(t)

    schema["events"].sort(key=lambda e: e.get("start", 0))
    schema["motifs"] = schema["motifs"][:MAX_MOTIFS]
    schema["threads"] = schema["threads"][:MAX_THREADS]
    log(f"  schema: {len(schema['characters'])} characters, "
        f"{len(schema['events'])} scene beats, {len(schema['motifs'])} motifs, "
        f"{len(schema['threads'])} threads")
    return schema


def build_initial_spine(schema: dict, log=print) -> str:
    llm = get_llm()
    text = llm.chat("You are a precise film archivist.",
                    SPINE_PROMPT.format(tok=SPINE_TOKENS,
                                        schema=json.dumps(schema)[:12000]),
                    max_tokens=SPINE_TOKENS + 100)
    spine = clip_to_tokens(" ".join(text.split()), SPINE_TOKENS)
    log(f"  story spine committed ({count_tokens(spine)}/{SPINE_TOKENS} tokens)")
    return spine


def refresh_spine(state: dict, log=print) -> str:
    """Re-summarize Tier 1 from the current Tier 2 state (commit-then-refresh)."""
    llm = get_llm()
    text = llm.chat("You are a precise film archivist.",
                    REFRESH_PROMPT.format(tok=SPINE_TOKENS,
                                          state=json.dumps(state, ensure_ascii=False)[:12000]),
                    max_tokens=SPINE_TOKENS + 100)
    spine = clip_to_tokens(" ".join(text.split()), SPINE_TOKENS)
    log(f"  story spine refreshed ({count_tokens(spine)}/{SPINE_TOKENS} tokens)")
    return spine
