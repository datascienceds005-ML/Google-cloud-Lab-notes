"""Layer 5 — Interaction.

Every question is answered from a freshly assembled ≤2,000-token window.
After the answer, new durable facts are committed to the State Store
(commit-then-refresh), and the window is discarded — nothing carries over.
"""
import json

from config import ANSWER_MAX_TOKENS
from pipeline.llm import extract_json, get_llm

ANSWER_SYSTEM = (
    "You answer questions about one movie using ONLY the CONTEXT provided. "
    "Cite timestamps like [mm:ss] whenever the context includes them. "
    "If the context does not contain the answer, say exactly what is missing "
    "instead of guessing."
)

ANSWER_INSTRUCTION = (
    "{window}\n\nAnswer the QUESTION at the end using only this context."
)

FACTS_PROMPT = """After this Q&A turn, extract durable new facts worth storing.
Return ONLY valid JSON with this exact shape:
{{"qa_line": "one-line digest of this Q&A (max 25 words)",
  "new_characters": [{{"name": "...", "aliases": [], "description": "..."}}],
  "scene_notes": [{{"start": 0.0, "end": 0.0, "note": "...", "characters": []}}],
  "motif_updates": ["..."],
  "thread_updates": ["..."]}}
Use empty lists when nothing is new. Do not repeat facts already in the context.

QUESTION: {q}
ANSWER: {a}"""

_EMPTY_FACTS = {"qa_line": "", "new_characters": [], "scene_notes": [],
                "motif_updates": [], "thread_updates": []}


def answer_question(question: str, store, log=None):
    llm = get_llm()
    window, report = store.assemble_window(question)

    answer = llm.chat(ANSWER_SYSTEM,
                      ANSWER_INSTRUCTION.format(window=window),
                      max_tokens=ANSWER_MAX_TOKENS)

    try:
        facts = extract_json(llm.chat(
            "You convert Q&A turns into memory updates. Reply with JSON only.",
            FACTS_PROMPT.format(q=question, a=answer), max_tokens=300))
    except Exception:
        facts = dict(_EMPTY_FACTS)

    digest = (facts.get("qa_line") or "").strip() or answer[:80]
    turn_no = store.commit_facts(facts, question, digest)
    refreshed = store.maybe_refresh_spine(llm, log=log)
    if log:
        log(f"  window {report['sections']['TOTAL']}/{report['cap']} tokens · "
            f"committed turn #{turn_no}" + (", spine refreshed" if refreshed else ""))
    return answer, report
