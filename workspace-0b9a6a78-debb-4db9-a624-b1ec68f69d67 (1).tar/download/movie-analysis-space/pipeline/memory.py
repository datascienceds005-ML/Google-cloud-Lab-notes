"""Layer 4 — Memory.

Four-tier external memory plus the fixed-context window assembler and the
automatic raw-file deletion gate.

  Tier 0  Active Window : ≤2,000 tokens, rebuilt per question, never persisted
  Tier 1  Story Spine   : rolling master summary (≤650 tokens)
  Tier 2  State Store   : characters / scenes / motifs / threads / Q&A digest
  Tier 3  Deep Archive  : verbatim transcript + on-screen captions

Commit-then-refresh: every answer produces a memory commit; the volatile
window dies immediately after. RepoSync optionally mirrors Tiers 1-3 to a
private dataset repo so state survives free-tier Space restarts.
"""
import json
import re
import shutil
import time
from pathlib import Path

from config import (ACTIVE_WINDOW_TOKENS, DATA_DIR, HF_TOKEN, DATASET_REPO,
                    QA_DIGEST_IN_WINDOW, QA_DIGEST_WINDOW, SPINE_REFRESH_EVERY,
                    SPINE_TOKENS)
from pipeline.tokens import clip_to_tokens, count_tokens

STOPWORDS = {
    "the", "and", "for", "are", "but", "not", "you", "all", "any", "can",
    "her", "was", "one", "our", "out", "day", "get", "has", "him", "his",
    "how", "man", "new", "now", "old", "see", "two", "way", "who", "boy",
    "did", "its", "let", "put", "say", "she", "too", "use", "that", "with",
    "have", "this", "will", "your", "from", "they", "know", "want", "were",
    "them", "what", "when", "then", "than", "there", "their", "would",
    "about", "which", "into", "does", "movie", "film", "scene", "happens",
}


def fmt_ts(sec: float) -> str:
    sec = max(0, int(sec or 0))
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def keywords(text: str) -> list:
    return [w for w in re.findall(r"[a-z']{3,}", (text or "").lower())
            if w not in STOPWORDS]


class MemoryStore:
    """Durable tiers on disk + the volatile Tier 0 assembler."""

    def __init__(self, film_id: str, title: str = ""):
        self.film_id = film_id
        self.title = title or film_id
        self.dir = DATA_DIR / film_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self.spine_path = self.dir / "spine.md"
        self.state_path = self.dir / "state.json"
        self.archive_path = self.dir / "archive.json"
        self.cleanup_path = self.dir / "cleanup.log"
        self.committed = False
        self.meta = {}
        self.last_window_report = {}
        self._load_or_init()

    # ── persistence ──────────────────────────────────────────────────────
    def _load_or_init(self):
        if self.state_path.exists():
            self.state = json.loads(self.state_path.read_text())
        else:
            self.state = {"characters": [], "scenes": [], "motifs": [],
                          "threads": [], "qa_digest": [],
                          "counters": {"qa_commits": 0}}
        self.archive = (json.loads(self.archive_path.read_text())
                        if self.archive_path.exists()
                        else {"transcript": [], "captions": []})
        self.spine = self.spine_path.read_text() if self.spine_path.exists() else ""
        self.committed = bool(self.spine.strip())
        meta_p = self.dir / "meta.json"
        if meta_p.exists():
            self.meta = json.loads(meta_p.read_text())
            self.title = self.title or self.meta.get("title", self.film_id)

    def save(self):
        self.state_path.write_text(json.dumps(self.state, ensure_ascii=False, indent=1))
        self.archive_path.write_text(json.dumps(self.archive, ensure_ascii=False))
        self.spine_path.write_text(self.spine)
        (self.dir / "meta.json").write_text(json.dumps(self.meta, ensure_ascii=False, indent=1))

    # ── durable commits ──────────────────────────────────────────────────
    def commit_schema(self, schema: dict, spine: str, transcript: list, captions: list):
        self.state["characters"] = schema["characters"]
        self.state["scenes"] = schema["events"]
        self.state["motifs"] = schema["motifs"]
        self.state["threads"] = schema["threads"]
        self.archive["transcript"] = transcript
        self.archive["captions"] = captions
        self.spine = spine
        self.meta["analyzed_at"] = time.strftime("%Y-%m-%d %H:%M")
        self.committed = True
        self.save()

    def commit_facts(self, facts: dict, question: str, digest_line: str) -> int:
        st = self.state
        for ch in facts.get("new_characters", []):
            name = str(ch.get("name", "")).strip()
            if not name:
                continue
            if not any(c["name"].casefold() == name.casefold()
                       for c in st["characters"]):
                st["characters"].append({"name": name,
                                         "aliases": list(ch.get("aliases", []))[:8],
                                         "description": str(ch.get("description", "")).strip()})
        for note in facts.get("scene_notes", []):
            try:
                start, end = float(note.get("start", 0)), float(note.get("end", 0))
            except (TypeError, ValueError):
                continue
            st["scenes"].append({"start": start, "end": max(end, start),
                                 "summary": str(note.get("note", "")).strip(),
                                 "characters": [str(c) for c in note.get("characters", [])][:8]})
        st["scenes"].sort(key=lambda s: s.get("start", 0))
        for mo in facts.get("motif_updates", []):
            mo = str(mo).strip()
            if mo and mo.casefold() not in {x.casefold() for x in st["motifs"]}:
                st["motifs"].append(mo)
        for th in facts.get("thread_updates", []):
            th = str(th).strip()
            if th and th.casefold() not in {x.casefold() for x in st["threads"]}:
                st["threads"].append(th)
        st["qa_digest"].append({"q": question, "digest": digest_line})
        st["qa_digest"] = st["qa_digest"][-QA_DIGEST_WINDOW:]
        st["counters"]["qa_commits"] = st["counters"].get("qa_commits", 0) + 1
        self.save()
        return st["counters"]["qa_commits"]

    def maybe_refresh_spine(self, llm, log=None) -> bool:
        n = self.state["counters"].get("qa_commits", 0)
        if n == 0 or n % SPINE_REFRESH_EVERY != 0:
            return False
        from pipeline.cognition import refresh_spine  # local import, no cycle
        self.spine = refresh_spine(self.state, log=log or print)
        self.save()
        return True

    # ── inspection ───────────────────────────────────────────────────────
    def tier_sizes(self) -> dict:
        return {
            "tier0_active_window_cap": ACTIVE_WINDOW_TOKENS,
            "tier1_story_spine": count_tokens(self.spine),
            "tier2_state_store": count_tokens(json.dumps(self.state, ensure_ascii=False)),
            "tier3_deep_archive": count_tokens(json.dumps(self.archive, ensure_ascii=False)),
        }

    def cleanup_log(self) -> str:
        return self.cleanup_path.read_text() if self.cleanup_path.exists() else "(gate not triggered yet)"

    # ── retrieval ────────────────────────────────────────────────────────
    def query_state(self, question: str):
        """Score Tier 2 records against the question. Returns (blocks, has_hits)."""
        kws = set(keywords(question))
        blocks = []
        for ch in self.state["characters"]:
            text = ch["name"]
            if ch.get("aliases"):
                text += f" (also: {', '.join(ch['aliases'])})"
            text += f" — {ch.get('description', '')}"
            blocks.append((sum(1 for k in kws if k in text.lower()), "CHARACTER", text))
        for sc in self.state["scenes"]:
            text = f"[{fmt_ts(sc.get('start', 0))}–{fmt_ts(sc.get('end', 0))}] {sc.get('summary', '')}"
            names = " ".join(sc.get("characters", []))
            blocks.append((sum(1 for k in kws if k in f"{text} {names}".lower()),
                           "SCENE", text))
        for mo in self.state["motifs"]:
            text = f"Motif: {mo}"
            blocks.append((sum(1 for k in kws if k in text.lower()), "MOTIF", text))
        for th in self.state["threads"]:
            text = f"Open thread: {th}"
            blocks.append((sum(1 for k in kws if k in text.lower()), "THREAD", text))

        blocks.sort(key=lambda b: -b[0])
        hits = [b for b in blocks if b[0] > 0]
        if hits:
            return hits, True
        default = ([b for b in blocks if b[1] == "CHARACTER"][:3]
                   + [b for b in blocks if b[1] == "SCENE"][:3])
        return default, False

    def rehydrate_archive(self, question: str, limit_segments: int = 12) -> str:
        """Tier 2 miss → pull verbatim lines out of the Tier 3 archive."""
        kws = set(keywords(question))
        scored = [(sum(1 for k in kws if k in seg["text"].lower()), seg)
                  for seg in self.archive["transcript"]]
        scored = [(s, seg) for s, seg in scored if s > 0]
        scored.sort(key=lambda x: -x[0])
        picks = [seg for _, seg in sorted(scored[:limit_segments],
                                          key=lambda x: x[1]["start"])]
        return "\n".join(f"[{fmt_ts(s['start'])}] {s['text']}" for s in picks)

    # ── Tier 0: fixed-context window assembler ──────────────────────────
    def _film_header(self) -> str:
        parts = [f"FILM: {self.title}"]
        if self.meta.get("analyzed_at"):
            parts.append(f"analyzed {self.meta['analyzed_at']}")
        parts.append(f"{len(self.archive['transcript'])} transcript segments, "
                     f"{len(self.archive['captions'])} caption cards")
        return " | ".join(parts)

    def _qa_block(self) -> str:
        pairs = self.state["qa_digest"][-QA_DIGEST_IN_WINDOW:]
        return "\n".join(f"Q: {p['q']}\nA: {p['digest']}" for p in pairs)

    def assemble_window(self, question: str):
        """Deterministically pack ≤ ACTIVE_WINDOW_TOKENS tokens.

        Order: film header → Story Spine (verbatim) → recent Q&A →
        question-matched Tier 2 records → (on miss) Tier 3 verbatim hits →
        the question itself. The window is volatile: nothing is stored.
        """
        budget = ACTIVE_WINDOW_TOKENS
        used = 0
        parts, report = [], {}

        def add(name, text, cap):
            nonlocal used
            if not text or cap <= 0:
                report[name] = 0
                return
            clipped = clip_to_tokens(text, min(cap, budget - used))
            if not clipped:
                report[name] = 0
                return
            part = f"### {name}\n{clipped}"
            n = count_tokens(part)
            parts.append(part)
            used += n
            report[name] = n

        qtok = count_tokens(question)
        reserve = qtok + 48  # question + its header + safety margin

        add("FILM", self._film_header(), 48)
        add("STORY SPINE (verbatim)", self.spine, SPINE_TOKENS)
        add("RECENT Q&A", self._qa_block(), 180)

        blocks, has_hits = self.query_state(question)
        archive_triggers = ("quote", "exact", "word", "said", "line",
                            "timestamp", "verbatim", "letter")
        want_archive = (not has_hits) or any(k in question.lower()
                                             for k in archive_triggers)
        records_room = max(0, budget - used - reserve - (260 if want_archive else 0))
        packed, rec_used = [], 0
        for _, _, text in blocks:
            c = count_tokens(text)
            if rec_used + c <= records_room:
                packed.append(text)
                rec_used += c
        add("RETRIEVED RECORDS (state store)", "\n".join(packed), records_room)

        if want_archive:
            hits = self.rehydrate_archive(question)
            add("ARCHIVE HITS (verbatim transcript)", hits, budget - used - reserve)

        parts.append(f"### QUESTION\n{question}")
        used += count_tokens(f"### QUESTION\n{question}")

        window = "\n\n".join(parts)
        if used > budget:  # belt-and-braces; by construction this is unreachable
            window = clip_to_tokens(window, budget)
            used = count_tokens(window)

        report["QUESTION"] = qtok
        report["TOTAL"] = used
        self.last_window_report = {"sections": report, "cap": budget}
        return window, self.last_window_report


class CleanupGate:
    """Automatic raw-file deletion.

    The gate stays CLOSED until durable records are committed to Tiers 1-3
    (spine non-empty + schema committed). Once open, raw media is erased from
    scratch disk without operator action and the deletion is logged.
    """

    def __init__(self, store: MemoryStore):
        self.store = store

    def _log(self, line: str):
        with open(self.store.cleanup_path, "a") as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {line}\n")

    def purge_raw_media(self, paths, log=None) -> dict:
        candidates = []
        for p in map(Path, paths):
            if p.is_dir():
                candidates.append((p, sum(f.stat().st_size for f in p.rglob("*") if f.is_file())))
            elif p.exists():
                candidates.append((p, p.stat().st_size))

        if not self.store.committed:
            status = "gate CLOSED — durable commit missing, raw media retained"
            self._log(status)
            return {"freed_mb": 0.0, "deleted": [], "status": status}

        freed, deleted = 0, []
        for p, size in candidates:
            if p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
            else:
                p.unlink(missing_ok=True)
            freed += size
            deleted.append(p.name)
        status = (f"gate OPEN — deleted {len(deleted)} raw item(s), "
                  f"{freed / 1e6:.1f} MB freed")
        self._log(f"{status}: {', '.join(deleted) if deleted else 'nothing staged'}")
        if log:
            log(f"  {status}")
        return {"freed_mb": round(freed / 1e6, 1), "deleted": deleted, "status": status}


class RepoSync:
    """Mirror Tiers 1-3 to a private HF dataset repo (survives Space restarts)."""

    def __init__(self, store: MemoryStore):
        self.store = store

    @staticmethod
    def enabled() -> bool:
        return bool(DATASET_REPO and HF_TOKEN)

    def sync(self, log=None) -> str:
        if not self.enabled():
            return ("repo mirror disabled — set the DATASET_REPO variable and "
                    "HF_TOKEN secret to persist across restarts")
        from huggingface_hub import HfApi
        api = HfApi(token=HF_TOKEN)
        for name in ("spine.md", "state.json", "archive.json"):
            api.upload_file(
                path_or_fileobj=str(self.store.dir / name),
                path_in_repo=f"films/{self.store.film_id}/{name}",
                repo_id=DATASET_REPO, repo_type="dataset",
                commit_message=f"memory snapshot: {self.store.film_id}/{name}")
        msg = (f"synced spine.md / state.json / archive.json → "
               f"{DATASET_REPO} · films/{self.store.film_id}")
        if log:
            log(f"  {msg}")
        return msg

    def restore(self, film_id: str) -> bool:
        """Pull tier files for film_id from the repo if not already on disk."""
        if not self.enabled() or (DATA_DIR / film_id / "state.json").exists():
            return False
        from huggingface_hub import snapshot_download
        tmp = snapshot_download(repo_id=DATASET_REPO, repo_type="dataset",
                                allow_patterns=f"films/{film_id}/*")
        src = Path(tmp) / "films" / film_id
        dst = DATA_DIR / film_id
        dst.mkdir(parents=True, exist_ok=True)
        copied = False
        for f in src.glob("*"):
            t = dst / f.name
            if not t.exists():
                shutil.copy(f, t)
                copied = True
        return copied
