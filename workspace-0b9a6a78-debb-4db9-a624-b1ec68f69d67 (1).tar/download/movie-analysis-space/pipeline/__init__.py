"""Movie analysis pipeline — 5 layers on top of a 4-tier fixed-context memory.

ingest        Layer 1  register lightweight upload on scratch disk
perception    Layer 2  shot-boundary keyframes, faster-whisper ASR, OCR captions
cognition     Layer 3  automated story schema (characters / scenes / motifs / threads)
memory        Layer 4  4-tier store, 2,000-token window assembler, cleanup gate
interaction   Layer 5  Q&A from a freshly assembled window + commit-then-refresh
"""
__all__ = ["ingest", "perception", "cognition", "memory", "interaction",
           "orchestrator", "llm", "tokens"]
