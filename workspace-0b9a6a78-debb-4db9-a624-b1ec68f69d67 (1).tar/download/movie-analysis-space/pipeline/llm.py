"""LLM access for Cognition (Layer 3) and Interaction (Layer 5).

The CPU Space itself never runs a large model. Default provider is the free
serverless HF Inference API (`hf_inference`, needs the HF_TOKEN secret).
`local` runs a small chat model with transformers on CPU (opt-in).
`mock` is a deterministic stub that lets the whole pipeline run with zero
network — used by the smoke test and useful for debugging wiring.
"""
import json
import re
import threading

from config import (ANSWER_MAX_TOKENS, HF_LLM_MODEL, HF_TOKEN, LLM_PROVIDER,
                    LLM_TEMPERATURE, LOCAL_LLM_MODEL)

_LOCK = threading.Lock()
_INSTANCE = None


def extract_json(text: str):
    """Pull the first balanced JSON object out of an LLM reply."""
    text = re.sub(r"```(?:json)?", "", text or "").strip()
    start = text.find("{")
    if start == -1:
        raise ValueError("no JSON object in model reply")
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return json.loads(text[start:i + 1])
    raise ValueError("unbalanced JSON in model reply")


class BaseLLM:
    name = "base"

    def chat(self, system: str, user: str, max_tokens: int = ANSWER_MAX_TOKENS) -> str:
        raise NotImplementedError


class MockLLM(BaseLLM):
    name = "mock (no network — for tests)"

    def chat(self, system, user, max_tokens=ANSWER_MAX_TOKENS):
        if "new_characters" in user:          # Layer 5 fact extraction
            return json.dumps({
                "qa_line": "Anna wants the lighthouse key returned before dawn.",
                "new_characters": [], "scene_notes": [],
                "motif_updates": [], "thread_updates": [],
            })
        if "MASTER SUMMARY" in user:          # Layer 3 spine build / refresh
            return ("Anna returns to her coastal hometown to find her missing sister. "
                    "Conflict with lighthouse keeper Mara over a hidden key drives the second act. "
                    "Motif: the lighthouse beam as memory. Open thread: the sister's last letter.")
        if "TRANSCRIPT PART" in user:         # Layer 3 per-chunk schema extraction
            return json.dumps({
                "characters": [{"name": "Anna", "aliases": ["An"],
                                "description": "Protagonist searching for her missing sister."}],
                "events": [{"start": 0.0, "end": 30.0,
                            "summary": "Anna argues with Mara about the lighthouse key.",
                            "characters": ["Anna", "Mara"]}],
                "motifs": ["lighthouse key"],
                "threads": ["Who keeps the lighthouse key?"],
            })
        return ("Per the story spine, Anna demands the lighthouse key at [00:00:30]; "
                "the beam motif frames her search for her sister.")


class HFInferenceLLM(BaseLLM):
    name = "hf_inference"

    def __init__(self):
        if not HF_TOKEN:
            raise RuntimeError(
                "LLM_PROVIDER=hf_inference needs the HF_TOKEN secret "
                "(Space settings → Variables and secrets)."
            )
        from huggingface_hub import InferenceClient
        self.client = InferenceClient(model=HF_LLM_MODEL, token=HF_TOKEN)

    def chat(self, system, user, max_tokens=ANSWER_MAX_TOKENS):
        messages = [{"role": "system", "content": system},
                    {"role": "user", "content": user}]
        last_err = None
        for attempt in (1, 2):
            try:
                resp = self.client.chat_completion(
                    messages=messages, max_tokens=max_tokens,
                    temperature=LLM_TEMPERATURE,
                )
                return (resp.choices[0].message.content or "").strip()
            except Exception as e:  # noqa: BLE001 — surface a useful message
                last_err = e
        raise RuntimeError(
            f"Inference API call failed twice ({HF_LLM_MODEL}): {last_err}. "
            "Check the HF_TOKEN secret, the model id, or set HF_LLM_MODEL to a "
            "model currently served on the serverless Inference API."
        )


class LocalLLM(BaseLLM):
    name = "local (transformers on CPU)"

    def __init__(self):
        self._bundle = None

    def _ensure(self):
        if self._bundle is None:
            try:
                import torch
                from transformers import AutoModelForCausalLM, AutoTokenizer
            except ImportError as e:
                raise RuntimeError(
                    "LLM_PROVIDER=local requires torch and transformers in "
                    "requirements.txt (they are opt-in to keep builds light)."
                ) from e
            tok = AutoTokenizer.from_pretrained(LOCAL_LLM_MODEL)
            mdl = AutoModelForCausalLM.from_pretrained(
                LOCAL_LLM_MODEL, torch_dtype="auto", low_cpu_mem_usage=True)
            mdl.eval()
            self._bundle = (tok, mdl, torch)

    def chat(self, system, user, max_tokens=ANSWER_MAX_TOKENS):
        self._ensure()
        tok, mdl, torch = self._bundle
        msgs = [{"role": "system", "content": system},
                {"role": "user", "content": user}]
        prompt = tok.apply_chat_template(msgs, tokenize=False,
                                         add_generation_prompt=True)
        inputs = tok(prompt, return_tensors="pt")
        with torch.inference_mode():
            out = mdl.generate(**inputs, max_new_tokens=min(max_tokens, 512),
                               do_sample=False)
        text = tok.decode(out[0][inputs["input_ids"].shape[1]:],
                          skip_special_tokens=True)
        return text.strip()


def get_llm() -> BaseLLM:
    global _INSTANCE
    with _LOCK:
        if _INSTANCE is None:
            if LLM_PROVIDER == "hf_inference":
                _INSTANCE = HFInferenceLLM()
            elif LLM_PROVIDER == "local":
                _INSTANCE = LocalLLM()
            elif LLM_PROVIDER == "mock":
                _INSTANCE = MockLLM()
            else:
                raise ValueError(f"unknown LLM_PROVIDER: {LLM_PROVIDER}")
        return _INSTANCE
