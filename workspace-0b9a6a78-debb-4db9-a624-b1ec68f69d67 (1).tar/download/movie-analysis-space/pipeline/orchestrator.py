"""End-to-end orchestration.

analyze_movie:  Layer 1 → 2 → 3 → durable commit (Layer 4) → cleanup gate →
                optional dataset mirror. One CPU-heavy batch per film.
ask:            Layer 5 via pipeline.interaction.answer_question.

SESSIONS keeps MemoryStore objects keyed by film_id for the lifetime of the
Space process; tier files on disk (and the dataset mirror) outlive it.
"""
import json
import threading
import time

from config import AUTO_SYNC
from pipeline.ingest import ingest_upload
from pipeline.perception import run_perception
from pipeline.cognition import build_story_schema, build_initial_spine
from pipeline.memory import CleanupGate, MemoryStore, RepoSync

_ANALYSIS_LOCK = threading.Lock()
SESSIONS = {}  # film_id → MemoryStore


def get_store(film_id: str, title: str = "") -> MemoryStore:
    if film_id not in SESSIONS:
        SESSIONS[film_id] = MemoryStore(film_id, title)
    return SESSIONS[film_id]


def analyze_movie(upload_path: str, display_title: str = "", log=print):
    if not _ANALYSIS_LOCK.acquire(blocking=False):
        raise RuntimeError("Another analysis is already running on this CPU "
                           "Space — one batch at a time. Try again when it finishes.")
    try:
        t0 = time.time()

        log("▶ Layer 1 · Ingest")
        ing = ingest_upload(upload_path, display_title)
        log(f"  film_id={ing.film_id} | {ing.size_mb:.0f} MB | "
            f"{ing.duration_s / 60:.0f} min | {ing.width}x{ing.height} | "
            f"audio={'yes' if ing.has_audio else 'no'}")

        perception = run_perception(ing, log)

        log("▶ Layer 3 · Cognition — automated story schema")
        schema = build_story_schema(perception, log)
        spine = build_initial_spine(schema, log)

        log("▶ Layer 4 · Memory — committing durable records (Tiers 1-3)")
        store = get_store(ing.film_id, ing.title)
        store.commit_schema(schema, spine,
                            perception["transcript"], perception["captions"])
        sizes = store.tier_sizes()
        log("  " + json.dumps(sizes))

        log("▶ Cleanup gate — automatic raw-file deletion")
        gate_res = CleanupGate(store).purge_raw_media(
            [ing.video_path, perception["audio_path"], perception["frames_dir"]],
            log=log)

        mirror = ""
        if AUTO_SYNC and RepoSync.enabled():
            log("▶ Dataset mirror (durability across restarts)")
            try:
                mirror = RepoSync(store).sync(log=log)
            except Exception as e:  # noqa: BLE001 — mirror is best-effort
                mirror = f"mirror failed: {e}"
                log(f"  ⚠ {mirror}")

        summary = {
            "film_id": ing.film_id,
            "title": ing.title,
            "runtime_min": round(ing.duration_s / 60, 1),
            "transcript_segments": len(perception["transcript"]),
            "caption_cards": len(perception["captions"]),
            "characters": len(schema["characters"]),
            "scene_beats": len(schema["events"]),
            "motifs": len(schema["motifs"]),
            "open_threads": len(schema["threads"]),
            "spine_tokens": sizes["tier1_story_spine"],
            "cleanup": gate_res["status"],
            "mirror": mirror,
            "elapsed_min": round((time.time() - t0) / 60, 1),
        }
        log(f"✅ Analysis complete in {summary['elapsed_min']} min — "
            "switch to tab ② to ask questions.")
        return ing.film_id, summary
    finally:
        _ANALYSIS_LOCK.release()


def restore_from_repo(film_id: str, log=print) -> bool:
    """Rehydrate tier files for a previous film_id from the dataset mirror."""
    if not RepoSync.enabled():
        log("  repo mirror not configured — nothing to restore")
        return False
    if RepoSync(get_store(film_id)).restore(film_id):
        log(f"  restored tier files for {film_id} from the dataset repo")
        return True
    log(f"  no stored snapshot for {film_id}")
    return False
