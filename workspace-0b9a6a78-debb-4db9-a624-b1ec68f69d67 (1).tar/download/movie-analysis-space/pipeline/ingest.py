"""Layer 1 — Ingest.

Registers the uploaded lightweight 480p/360p movie on the ephemeral scratch
disk and probes it with ffprobe. Nothing here ever enters the model context;
raw media lives on scratch only until the cleanup gate erases it.
"""
import json
import re
import shutil
import subprocess
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from config import SCRATCH_DIR

ALLOWED_EXT = {".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v"}
MAX_UPLOAD_GB = 2.0


@dataclass
class IngestResult:
    film_id: str
    title: str
    video_path: str
    work_dir: str
    size_mb: float
    duration_s: float = 0.0
    width: int = 0
    height: int = 0
    has_audio: bool = True


def slugify(text: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return s or "film"


def _ffprobe(path: Path) -> dict:
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "quiet", "-print_format", "json",
             "-show_format", "-show_streams", str(path)],
            capture_output=True, text=True, timeout=120)
        data = json.loads(out.stdout or "{}")
    except Exception:
        return {}
    fmt = data.get("format", {})
    w = h = 0
    has_audio = False
    for s in data.get("streams", []):
        if s.get("codec_type") == "video" and not w:
            w, h = int(s.get("width", 0)), int(s.get("height", 0))
        if s.get("codec_type") == "audio":
            has_audio = True
    return {"duration_s": float(fmt.get("duration", 0) or 0),
            "width": w, "height": h, "has_audio": has_audio}


def ingest_upload(upload_path: str, display_title: str = "") -> IngestResult:
    src = Path(upload_path)
    if not src.exists():
        raise ValueError("uploaded file not found")
    ext = src.suffix.lower()
    if ext not in ALLOWED_EXT:
        raise ValueError(f"unsupported container {ext!r}; "
                         f"expected one of {sorted(ALLOWED_EXT)}")
    size = src.stat().st_size
    if size > MAX_UPLOAD_GB * 1024 ** 3:
        raise ValueError(f"file too large ({size / 1e9:.1f} GB); "
                         f"this pipeline expects lightweight ~0.5-0.6 GB encodes")

    title = (display_title or "").strip() or src.stem
    film_id = f"{slugify(title)[:40]}-{uuid.uuid4().hex[:6]}"
    work_dir = SCRATCH_DIR / film_id
    work_dir.mkdir(parents=True, exist_ok=True)

    video_path = work_dir / f"source{ext}"
    try:
        shutil.move(str(src), video_path)          # same device: instant
    except OSError:
        shutil.copy(str(src), video_path)          # cross-device fallback
        src.unlink(missing_ok=True)

    probe = _ffprobe(video_path)
    meta = {"film_id": film_id, "title": title,
            "size_mb": round(size / 1e6, 1), "ingested_at": uuid.uuid4().hex[:0],
            **probe}
    (work_dir / "meta.json").write_text(json.dumps(meta, indent=2))

    return IngestResult(
        film_id=film_id, title=title, video_path=str(video_path),
        work_dir=str(work_dir), size_mb=size / 1e6,
        duration_s=probe.get("duration_s", 0.0),
        width=probe.get("width", 0), height=probe.get("height", 0),
        has_audio=probe.get("has_audio", True),
    )
