"""Layer 2 — Perception.

Extracts text-level evidence from the movie, strictly on CPU:
  * shot-boundary keyframes via OpenCV HSV-histogram cut detection,
  * dialogue transcript via faster-whisper (int8, VAD on),
  * on-screen captions via Tesseract OCR on the keyframes.

Raw media (video / wav / frames) stays on scratch disk and is erased by the
cleanup gate once these artifacts are committed to the memory tiers.
Heavy imports are done inside functions so the UI and memory layers load fast.
"""
import json
import subprocess
from pathlib import Path

from config import (FRAME_SCAN_FPS, KEYFRAME_HEIGHT, MAX_KEYFRAMES, OCR_ENABLED,
                    SHOT_THRESHOLD, WHISPER_COMPUTE, WHISPER_MODEL)


def extract_audio(video_path: Path, out_wav: Path) -> bool:
    """ffmpeg: strip video, 16 kHz mono PCM — the format faster-whisper wants."""
    proc = subprocess.run(
        ["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ac", "1",
         "-ar", "16000", "-f", "wav", str(out_wav)],
        capture_output=True, text=True, timeout=3600)
    return proc.returncode == 0 and out_wav.exists()


def _scan_shot_distances(video_path: Path, log) -> list:
    import cv2

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError("OpenCV cannot open the video file")
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    step = max(1, int(round(src_fps / FRAME_SCAN_FPS)))
    prev, dists, idx = None, [], 0
    while True:
        if not cap.grab():
            break
        if idx % step == 0:
            ok, frame = cap.retrieve()
            if not ok:
                break
            ts = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
            small = cv2.resize(frame, (160, 90))
            hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
            hist = cv2.calcHist([hsv], [0, 1, 2], None, [8, 8, 8],
                                [0, 180, 0, 256, 0, 256])
            cv2.normalize(hist, hist)
            if prev is not None:
                corr = cv2.compareHist(prev, hist, cv2.HISTCMP_CORREL)
                dists.append((ts, max(0.0, 1.0 - corr)))
            prev = hist
        idx += 1
    cap.release()
    log(f"  scanned {idx} frames ({len(dists)} samples @ {FRAME_SCAN_FPS:g} fps) for cuts")
    return dists


def extract_keyframes(video_path: Path, frames_dir: Path, log) -> list:
    """Two-pass: score cut candidates, then decode only the chosen timestamps."""
    import cv2

    frames_dir.mkdir(parents=True, exist_ok=True)
    dists = _scan_shot_distances(video_path, log)
    cands = [(ts, d) for ts, d in dists if d >= SHOT_THRESHOLD]
    cands.sort(key=lambda x: -x[1])
    picks = sorted(ts for ts, _ in cands[:MAX_KEYFRAMES - 1])

    if len(picks) < 3:  # slow/art-house cuts: fall back to uniform sampling
        duration = dists[-1][0] if dists else 0.0
        stride = max(60.0, duration / max(1, MAX_KEYFRAMES))
        picks = [i * stride for i in range(int(duration // stride) + 1)][:MAX_KEYFRAMES]
        log("  few hard cuts detected — uniform keyframe sampling instead")

    if not picks or picks[0] > 0.5:
        picks = [0.0] + picks
    picks = picks[:MAX_KEYFRAMES]

    cap = cv2.VideoCapture(str(video_path))
    saved = []
    for i, ts in enumerate(picks):
        cap.set(cv2.CAP_PROP_POS_MSEC, ts * 1000.0)
        ok, frame = cap.read()
        if not ok:
            continue
        h, w = frame.shape[:2]
        if h > KEYFRAME_HEIGHT:
            frame = cv2.resize(frame, (int(w * KEYFRAME_HEIGHT / h), KEYFRAME_HEIGHT))
        p = frames_dir / f"kf_{i:03d}_t{ts:08.1f}.jpg"
        cv2.imwrite(str(p), frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        saved.append({"path": str(p), "t": round(ts, 1)})
    cap.release()
    log(f"  saved {len(saved)} keyframes to scratch (cap {MAX_KEYFRAMES})")
    return saved


def transcribe_audio(audio_path: Path, log) -> list:
    from faster_whisper import WhisperModel

    model = WhisperModel(WHISPER_MODEL, device="cpu", compute_type=WHISPER_COMPUTE)
    segments, info = model.transcribe(str(audio_path), vad_filter=True, beam_size=1)
    out = []
    for seg in segments:  # lazy generator — consumed here
        text = seg.text.strip()
        if text:
            out.append({"start": round(seg.start, 1), "end": round(seg.end, 1),
                        "text": text})
        if len(out) % 50 == 0:
            log(f"  transcribed {len(out)} segments…")
    log(f"  transcript done: {len(out)} segments "
        f"(language={getattr(info, 'language', '?')}, model={WHISPER_MODEL}/{WHISPER_COMPUTE})")
    return out


def ocr_keyframes(keyframes: list, log) -> list:
    import pytesseract
    from PIL import Image

    out = []
    for kf in keyframes:
        try:
            img = Image.open(kf["path"])
            txt = pytesseract.image_to_string(img, config="--psm 6")
        except Exception:
            continue
        lines = [ln.strip() for ln in txt.splitlines()
                 if len(ln.strip()) >= 4 and sum(c.isalpha() for c in ln) >= 4]
        if lines:
            out.append({"t": kf["t"], "text": " | ".join(lines[:6])})
    log(f"  OCR: on-screen text on {len(out)} frames")
    return out


def run_perception(ingest, log) -> dict:
    log("▶ Layer 2 · Perception")
    wd = Path(ingest.work_dir)
    audio = wd / "audio16k.wav"
    frames_dir = wd / "keyframes"

    has_audio = bool(ingest.has_audio)
    if has_audio:
        log("  extracting 16 kHz mono audio with ffmpeg…")
        has_audio = extract_audio(Path(ingest.video_path), audio)
        if not has_audio:
            log("  ⚠ audio extraction failed — continuing without transcript")

    transcript = transcribe_audio(audio, log) if has_audio else []
    keyframes = extract_keyframes(Path(ingest.video_path), frames_dir, log)
    captions = ocr_keyframes(keyframes, log) if OCR_ENABLED else []

    (wd / "transcript.jsonl").write_text(
        "\n".join(json.dumps(s, ensure_ascii=False) for s in transcript))
    (wd / "captions.jsonl").write_text(
        "\n".join(json.dumps(c, ensure_ascii=False) for c in captions))
    log("  perception artifacts staged on scratch (transcript.jsonl, captions.jsonl)")

    return {"transcript": transcript, "captions": captions,
            "keyframes": keyframes, "audio_path": str(audio),
            "frames_dir": str(frames_dir)}
