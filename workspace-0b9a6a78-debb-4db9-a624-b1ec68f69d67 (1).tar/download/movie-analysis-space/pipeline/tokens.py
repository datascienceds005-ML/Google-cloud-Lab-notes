"""Token accounting for the fixed 2,000-token ceiling.

tiktoken (cl100k_base) is the counting standard so the cap is deterministic.
If tiktoken is unavailable the module falls back to a conservative
whitespace heuristic (never underestimates by much, never overflows).
"""
import re

try:
    import tiktoken as _tk

    _enc = _tk.get_encoding("cl100k_base")

    def count_tokens(text: str) -> int:
        return len(_enc.encode(text or ""))

    def clip_to_tokens(text: str, max_tokens: int) -> str:
        if max_tokens <= 0:
            return ""
        ids = _enc.encode(text or "")
        if len(ids) <= max_tokens:
            return text or ""
        return _enc.decode(ids[:max_tokens]).strip()

except Exception:  # pragma: no cover — fallback path

    def count_tokens(text: str) -> int:
        text = text or ""
        words = re.findall(r"\S+", text)
        return max(1, int(len(words) * 1.35) + text.count("\n"))

    def clip_to_tokens(text: str, max_tokens: int) -> str:
        if max_tokens <= 0:
            return ""
        out, used = [], 0
        for w in re.findall(r"\S+", text or ""):
            cost = int(len(w) / 3.5) + 1
            if used + cost > max_tokens:
                break
            out.append(w)
            used += cost
        return " ".join(out)
